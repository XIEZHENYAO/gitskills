package notes

import (
	"io"
	"os"
	"strconv"
	"strings"
)

//获取本进程的pid并记录到文本
func PidNote() error {
	ex := strings.Split(os.Args[0], "\\")
	ex = strings.Split(ex[len(ex)-1], "/")

	pid := os.Getpid()
	file, err := os.Create(ex[len(ex)-1] + ".pid")
	if err != nil {
		return err
	}
	defer file.Close()

	_, err = io.WriteString(file, strconv.Itoa(pid))
	if err != nil {
		return err
	}
	return nil
}
