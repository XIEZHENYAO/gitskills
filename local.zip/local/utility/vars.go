/*
	工具集

	方便使用 map[string]interface{} 的对象

	Donnie.L
	2015.06
*/

package utility

import (
	"reflect"
	// "bytes"
	// "encoding/json"
	// "fmt"
	// "github.com/bitly/go-simplejson"
	// "reflect"
	// "strconv"
	// "strings"
	// "time"
)

type Var struct {
	d interface{}
}

func NewVar(v interface{}) *Var {
	return &Var{v}
}

func (v *Var) Interface() interface{} {
	return v.d
}
func (v *Var) Int() int {
	return Int(v.d)
}
func (v *Var) Float32() float32 {
	return Float32(v.d)
}
func (v *Var) Str() string {
	return Str(v.d)
}

// do I have a non-nil value ?
func (v *Var) Ok() bool {
	return v.d != nil
}

func (v *Var) Get(field string) *Var {
	m := v.asMap()
	if m == nil {
		return &Var{}
	}
	d, ok := m[field]
	if !ok {
		return &Var{}
	}
	return &Var{d}
}

func (v *Var) GetPath(fields ...string) *Var {
	t := &Var{v.d}
	for _, f := range fields {
		t = t.Get(f)
	}
	return t
}

// get array element at idx
func (v *Var) GetIndex(idx int) *Var {
	a := v.Array()
	if a == nil {
		return &Var{}
	}
	if idx < 0 || idx >= len(a) {
		return &Var{}
	}
	return &Var{a[idx]}
}

// return []interface{} or nil
func (v *Var) Array() []interface{} {
	if v.d == nil {
		return nil
	}
	if a, ok := v.d.([]interface{}); ok {
		return a
	}
	refval := reflect.ValueOf(v.d)
	if refval.Interface() != nil {
		if refval.Type().ConvertibleTo(reflect.TypeOf(emp_ifacearray)) {
			return refval.Convert(reflect.TypeOf(emp_ifacearray)).Interface().([]interface{})
		}
	}
	return nil
}

func (v *Var) asMap() map[string]interface{} {
	if v.d == nil {
		return nil
	}
	if m, ok := v.d.(map[string]interface{}); ok {
		return m
	}
	refval := reflect.ValueOf(v.d)
	if refval.Interface() != nil {
		if refval.Type().ConvertibleTo(reflect.TypeOf(emp_stringiface)) {
			return refval.Convert(reflect.TypeOf(emp_stringiface)).Interface().(map[string]interface{})
		}
	}
	return nil
}

var emp_ifacearray []interface{}
var emp_stringiface map[string]interface{}
