/*
	工具集

	Donnie.L
	2015.06
*/

package utility

import (
	"bytes"
	"container/heap"
	"encoding/json"
	"fmt"
	"math"
	"math/rand"
	"reflect"
	"strconv"
	"strings"
	"time"
	"unsafe"

	"github.com/bitly/go-simplejson"
	"github.com/cihub/seelog"
)

// map string->interface
type SImap map[string]interface{}

// map interface->interface
type IImap map[interface{}]interface{}

// slice interface
type Ivec []interface{}

// 用于对比指定变量类型是否time.Time
var val_default_time_ time.Time

// 2006-01-02 15:04:05 格式时间
var TimeFmt string = "2006-01-02 15:04:05"

func Str(v interface{}) string {
	switch a := v.(type) {
	case string:
		return a
	case []byte:
		return string(a)
	case json.Number:
		return string(a)
	case float32:
		return strconv.FormatFloat(float64(a), 'f', -1, 32)
	case float64:
		return strconv.FormatFloat(a, 'f', -1, 64)
	case int:
		return strconv.FormatInt(int64(a), 10) // return strconv.Itoa(a)
	case int8:
		return strconv.FormatInt(int64(a), 10)
	case int16:
		return strconv.FormatInt(int64(a), 10)
	case int32:
		return strconv.FormatInt(int64(a), 10)
	case int64:
		return strconv.FormatInt(a, 10)
	case uint:
		return strconv.FormatUint(uint64(a), 10)
	case uint8:
		return strconv.FormatUint(uint64(a), 10)
	case uint16:
		return strconv.FormatUint(uint64(a), 10)
	case uint32:
		return strconv.FormatUint(uint64(a), 10)
	case uint64:
		return strconv.FormatUint(a, 10)
	case bool:
		return strconv.FormatBool(a)
	case complex64, complex128:
		return fmt.Sprintf("%v", a)
	case *simplejson.Json:
		return Str(a.Interface())
	// 所有不符合以上case的都落入interface{}
	case interface{}: // *interface{}也符合此条件...refval.Kind() == reflect.Ptr
		refval := reflect.ValueOf(a)
		if refval.Kind() == reflect.Ptr {
			refval = reflect.Indirect(refval)
		}
		// check nil first, else Kind() will crash
		if refval.Interface() == nil {
			return ""
		}
		vv := reflect.ValueOf(refval.Interface())
		switch vv.Type().Kind() {
		case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
			return Str(vv.Int())
		case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64:
			return Str(vv.Uint())
		case reflect.Float32, reflect.Float64:
			return Str(vv.Float())
		case reflect.String:
			return vv.String()
		case reflect.Array, reflect.Slice:
			switch vv.Type().Elem().Kind() {
			case reflect.Uint8:
				data := refval.Interface().([]byte)
				return string(data)
			}
		case reflect.Bool:
			return Str(vv.Bool())
		case reflect.Complex128, reflect.Complex64:
			return Str(vv.Complex())
		//时间类型
		case reflect.Struct:
			if vv.Type().ConvertibleTo(reflect.TypeOf(val_default_time_)) {
				// time format:
				//	月 - 1
				//	日 - 2
				//	时 - 3（如果是24小时制，就是15）
				//	分 - 4
				//	秒 - 5
				//	年 - 6
				//	时区 - 7
				//   2006-01-02 15:04:05 = yyyy-MM-dd HH:mm:ss
				return refval.Convert(reflect.TypeOf(val_default_time_)).Interface().(time.Time).Format(time.RFC3339Nano)
			}
			/* unsupported types below
			   case reflect.Map:
			   case reflect.Ptr:
			   case reflect.Uintptr:
			   case reflect.UnsafePointer:
			   case reflect.Chan, reflect.Func, reflect.Interface:
			*/
		}
		//		return "unknow interface{}"
	}
	return ""
}

func Int(v interface{}) int {
	return int(Int64(v))
}

func Int64(v interface{}) int64 {
	switch a := v.(type) {
	case string:
		return str2int(a)
	case []byte:
		s := string(a)
		return str2int(s)
	case json.Number:
		s := string(a)
		return str2int(s)
	case float32:
		return int64(a)
	case float64:
		return int64(a)
	case int:
		return int64(a)
	case int8:
		return int64(a)
	case int16:
		return int64(a)
	case int32:
		return int64(a)
	case int64:
		return a
	case uint:
		return int64(a)
	case uint8:
		return int64(a)
	case uint16:
		return int64(a)
	case uint32:
		return int64(a)
	case uint64:
		return int64(a)
	case bool:
		if a {
			return 1
		}
		return 0
	case complex64, complex128:
		return 0
	case *simplejson.Json:
		return Int64(a.Interface())
	// 所有不符合以上case的都落入interface{}
	case interface{}: // *interface{}也符合此条件...refval.Kind() == reflect.Ptr
		refval := reflect.ValueOf(a)
		if refval.Kind() == reflect.Ptr {
			refval = reflect.Indirect(refval)
		}
		// check nil first, else Kind() will crash
		if refval.Interface() == nil {
			return 0
		}
		vv := reflect.ValueOf(refval.Interface())
		switch vv.Type().Kind() {
		case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
			return vv.Int()
		case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64:
			return Int64(vv.Uint())
		case reflect.Float32, reflect.Float64:
			return Int64(vv.Float())
		case reflect.String:
			return Int64(vv.String())
		case reflect.Array, reflect.Slice:
			switch vv.Type().Elem().Kind() {
			case reflect.Uint8:
				data := refval.Interface().([]byte)
				return Int64(string(data))
			}
		case reflect.Bool:
			return Int64(vv.Bool())
		case reflect.Complex128, reflect.Complex64:
			return Int64(vv.Complex())
		//时间类型
		case reflect.Struct:
			if vv.Type().ConvertibleTo(reflect.TypeOf(val_default_time_)) {
				return refval.Convert(reflect.TypeOf(val_default_time_)).Interface().(time.Time).Unix()
			}
		}
	}
	return 0
}

var Float = Float64

func Float32(v interface{}) float32 {
	return float32(Float64(v))
}
func Float64(v interface{}) float64 {
	switch a := v.(type) {
	case string:
		return str2float(a)
	case []byte:
		s := string(a)
		return str2float(s)
	case json.Number:
		s := string(a)
		return str2float(s)
	case float32:
		return float64(a)
	case float64:
		return a
	case int:
		return float64(a)
	case int8:
		return float64(a)
	case int16:
		return float64(a)
	case int32:
		return float64(a)
	case int64:
		return float64(a)
	case uint:
		return float64(a)
	case uint8:
		return float64(a)
	case uint16:
		return float64(a)
	case uint32:
		return float64(a)
	case uint64:
		return float64(a)
	case bool:
		if a {
			return 1
		}
		return 0
	case complex64, complex128:
		return 0
	case *simplejson.Json:
		return Float64(a.Interface())
	// 所有不符合以上case的都落入interface{}
	case interface{}: // *interface{}也符合此条件...refval.Kind() == reflect.Ptr
		refval := reflect.ValueOf(a)
		if refval.Kind() == reflect.Ptr {
			refval = reflect.Indirect(refval)
		}
		// check nil first, else Kind() will crash
		if refval.Interface() == nil {
			return 0
		}
		vv := reflect.ValueOf(refval.Interface())
		switch vv.Type().Kind() {
		case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
			return Float64(vv.Int())
		case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64:
			return Float64(vv.Uint())
		case reflect.Float32, reflect.Float64:
			return (vv.Float())
		case reflect.String:
			return Float64(vv.String())
		case reflect.Array, reflect.Slice:
			switch vv.Type().Elem().Kind() {
			case reflect.Uint8:
				data := refval.Interface().([]byte)
				return Float64(string(data))
			}
		case reflect.Bool:
			return Float64(vv.Bool())
		case reflect.Complex128, reflect.Complex64:
			return Float64(vv.Complex())
		//时间类型
		case reflect.Struct:
			if vv.Type().ConvertibleTo(reflect.TypeOf(val_default_time_)) {
				return Float64(refval.Convert(reflect.TypeOf(val_default_time_)).Interface().(time.Time).Unix())
			}
		}
	}
	return 0
}

func str2int(s string) int64 {
	r, err := strconv.ParseInt(s, 10, 0)
	if err == nil {
		return int64(r)
	} else if strings.Index(s, ".") >= 0 {
		r, err := strconv.ParseFloat(s, 64)
		if err == nil {
			return int64(r)
		}
	}
	return 0
}

func str2float(s string) float64 {
	r, err := strconv.ParseFloat(s, 64)
	if err == nil {
		return r
	}
	return 0.0
}

// TrimSplit split string and return trim space string
func SplitAndTrim(s, sep string) []string {
	sp := strings.Split(s, sep)
	for i, n := 0, len(sp); i < n; i++ {
		sp[i] = strings.TrimSpace(sp[i])
	}

	return sp
}

//	value to JSON-String
//	错误时返回错误信息
func Val2JsonStr(val interface{}) string {
	return string(Val2JsonByte(val))
}

//	value to JSON-String in []byte， 简单封装而已
//	错误时返回错误信息
func Val2JsonByte(val interface{}) []byte {
	b_json, err := json.Marshal(val) //Val2sjson(val).MarshalJSON()
	if err == nil {
		return b_json
	}
	return []byte(err.Error())
}

//	value to pretty JSON-String
//	错误时返回错误信息
func Val2JsonStrPretty(val interface{}) string {
	var buff bytes.Buffer
	json.Indent(&buff, Val2JsonByte(val), "", "    ")
	return buff.String()
}

//	simplejson.NewJson : empty
func NewSPJson() *simplejson.Json {
	return simplejson.New()
}

//	simplejson.NewJson : string version
func NewSPJsonFromStr(s string) (*simplejson.Json, error) {
	return simplejson.NewJson([]byte(s))
}

//	value to simplejson
func Val2SPJson(val interface{}) *simplejson.Json {
	js := simplejson.New()
	js.SetPath(nil, val)
	return js
}

// 从simplejson按整数获取字段值
func SPJsonGetn(js *simplejson.Json, field string) int {
	return Int(js.Get(field).Interface())
}

// 从simplejson按浮点数获取字段值
func SPJsonGetf(js *simplejson.Json, field string) float64 {
	return Float(js.Get(field).Interface())
}

// 从simplejson按字符串获取字段值
func SPJsonGets(js *simplejson.Json, field string) string {
	return Str(js.Get(field).Interface())
}

/*




	将数据尽量转换成可序列化的类型并返回
	主要用于结构中，需要得到未导出数据而无法直接访问的情形，所有结构都将转成map[string]interface{}返回
	对于其他数据类型意义不大
	* 不支持数据内递归嵌套！
	array和slice会转换成 []interface{}
	map视key类型会返回这几种：
		map[string]interface{},map[int64]interface{},map[uint64]interface{},map[interface{}]interface{}

*/
func TryMoreSerialize(val interface{}) interface{} {
	switch f := val.(type) {
	case reflect.Value:
		return getReflectValue(f)
	default:
		return getReflectValue(reflect.ValueOf(val))
	}
}

func getReflectValue(value reflect.Value) interface{} {
	switch f := value; f.Kind() {
	case reflect.Invalid:
		return "<invalid reflect.Value>"
	case reflect.Interface:
		if f.IsNil() {
			break
		}
		return getReflectValue(f.Elem())
	case reflect.Bool:
		return f.Bool()
	case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
		return f.Int()
	case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64, reflect.Uintptr:
		return f.Uint()
	case reflect.String:
		return f.String()
	case reflect.Float32, reflect.Float64:
		if f.Type().Size() == 4 {
			return float32(f.Float())
		} else {
			return f.Float()
		}
	case reflect.Complex64, reflect.Complex128:
		if f.Type().Size() == 8 {
			return complex64(f.Complex())
		} else {
			return f.Complex()
		}
	case reflect.Array, reflect.Slice:
		sl := make([]interface{}, f.Len())
		for i := 0; i < f.Len(); i++ {
			sl[i] = getReflectValue(f.Index(i))
		}
		return sl
	case reflect.Map:
		//		fmt.Println(f.Type(), f.Type().Key(), f.Type().Elem())
		switch f.Type().Key().Kind() {
		case reflect.String:
			m := make(map[string]interface{}, f.Len())
			keys := f.MapKeys()
			for _, key := range keys {
				kv := key.String()
				vv := getReflectValue(f.MapIndex(key))
				m[kv] = vv
			}
			return m
		case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
			m := make(map[int64]interface{}, f.Len())
			keys := f.MapKeys()
			for _, key := range keys {
				kv := key.Int()
				vv := getReflectValue(f.MapIndex(key))
				m[kv] = vv
			}
			return m
		case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64, reflect.Uintptr:
			m := make(map[uint64]interface{}, f.Len())
			keys := f.MapKeys()
			for _, key := range keys {
				kv := key.Uint()
				vv := getReflectValue(f.MapIndex(key))
				m[kv] = vv
			}
			return m
		default:
			m := make(map[interface{}]interface{}, f.Len())
			keys := f.MapKeys()
			for _, key := range keys {
				kv := getReflectValue(key)
				if kv == nil {
					continue
				}
				vv := getReflectValue(f.MapIndex(key))
				m[kv] = vv
			}
			return m
		}
	case reflect.Struct:
		//	转换成map
		m := make(map[string]interface{}, f.NumField())
		for i := 0; i < f.NumField(); i++ {
			field := f.Type().Field(i)
			if field.Name == "" {
				continue
			}
			v := f.Field(i)
			if f.Kind() == reflect.Interface && !f.IsNil() {
				v = f.Elem()
			}
			m[field.Name] = getReflectValue(v)
		}
		return m
	case reflect.Ptr:
		if f.IsNil() {
			break
		}
		v := f.Elem()
		return getReflectValue(v)
	case reflect.Chan, reflect.Func:
		if f.IsNil() {
			break
		}
		fallthrough
	case reflect.UnsafePointer:
		u := value.Pointer()
		return fmt.Sprintf("0x%08x", u)
	}
	return nil
}

//
//
//
//
// 按层次提取复杂数据结构src中的数据对象，
//	如果最终数据是简单类型数据(number/string)直接返回该数据
//	否则返回描述该数据的reflect.Value
// 如果尝试分解的src为简单数据， 将返回 nil；但如果src是简单数据而fields_param为空则直接返回该数据(不算分解)
// fields_param: 用句点.分割开每层字段名的层次描述:"obj.name"
//	以下字段名有特殊含义(对非适合对象使用这些特殊操作将直接返回nil)：
//		#:  表示取对象长度，用于 Array, Slice, Map, Chan, String
//		##: 表示取对象cap，用于 Array, Slice, Chan
//		[]: 表示取对象keys，返回[]reflect.Value，用于 Struct, Map, 如果是Array, Slice仅返回Len()
//		[s]:表示取对象可读keys，，用于Struct返回[]string, 用于Map返回[]interface{}, 用于Array, Slice[]int
//			用于Map返回[]interface{}中，单元内存放的是map的key类型数据(简单类型key)或者reflect.Value(复杂类型key)
func ExtractData(src interface{}, fields_param string) interface{} {
	defer func() {
		if r := recover(); r != nil {
			seelog.Error("Recovered: ", r)
		}
	}()

	val := ToReflectValueFinal(src)

	fields := SplitAndTrim(fields_param, ".")

	for _, field := range fields {
		if len(field) == 0 {
			break
		}
		switch field {
		case "#": // len
			switch f := val; f.Kind() {
			case reflect.Array, reflect.Slice, reflect.Map, reflect.Chan, reflect.String:
				return val.Len()
			case reflect.Struct:
				return val.NumField()
			default:
				return nil
			}
		case "##": // cap
			switch f := val; f.Kind() {
			case reflect.Array, reflect.Slice, reflect.Chan:
				return val.Cap()
			default:
				return nil
			}
		case "[]": // keys
			switch f := val; f.Kind() {
			case reflect.Struct:
				v := make([]reflect.Value, val.NumField())
				for i := 0; i < val.NumField(); i++ {
					v[i] = val.Field(i)
				}
				return v
			case reflect.Array, reflect.Slice:
				return val.Len() // array不太需要
			case reflect.Map:
				return f.MapKeys()
			default:
				return nil
			}
		case "[s]": // read-able keys
			switch f := val; f.Kind() {
			case reflect.Struct:
				v := make([]string, val.NumField())
				for i := 0; i < val.NumField(); i++ {
					v[i] = val.Type().Field(i).Name
				}
				return v
			case reflect.Array, reflect.Slice:
				v := make([]int, val.Len())
				for i := 0; i < val.Len(); i++ {
					v[i] = i
				}
				return v
			case reflect.Map:
				vk := f.MapKeys()
				v := make([]interface{}, len(vk))
				for i, v0 := range vk {
					v[i] = ExtraReflectValue(v0)
				}
				return v
			default:
				return nil
			}
		default: // get value
			switch f := val; f.Kind() {
			case reflect.Struct:
				//seelog.Debugf("struct: %s in type %v", field, val.Type())
				val = val.FieldByName(field)
				if !val.IsValid() {
					return nil
				}
			case reflect.Array, reflect.Slice:
				//seelog.Debugf("array/slice: %s", field)
				r, err := strconv.ParseInt(field, 10, 0)
				if err != nil {
					return nil
				}
				idx := int(r)
				if idx < 0 || idx >= val.Len() {
					return nil
				}
				val = val.Index(idx)
			case reflect.Map:
				//seelog.Debugf("map: %s in type %v", field, val.Type())
				var key reflect.Value
				switch val.Type().Key().Kind() {
				case reflect.String:
					key = ToReflectValueFinal(field)
				case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
					n := Int64(field)
					key = ToReflectValueFinal(n).Convert(val.Type().Key())
				case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64, reflect.Uintptr:
					n := uint64(Int64(field))
					key = ToReflectValueFinal(n).Convert(val.Type().Key())
				case reflect.Float32, reflect.Float64:
					r := Float64(field)
					key = ToReflectValueFinal(r).Convert(val.Type().Key())
				default:
					return nil
				}
				val = val.MapIndex(key)
			default:
				//seelog.Debugf("can't index value type %v", f.Type())
				return nil // 简单类型不支持索引
			}
		} //switch field
		val = ToReflectValueFinal(val)
		//seelog.Debugf("val after toReflectValue %v", val.Type())
	}

	return ExtraReflectValue(val)
}

// 转换成reflect.Value，并保证src是interface{}或者Ptr时返回的是其对象的reflect.Value
func ToReflectValueFinal(src interface{}) reflect.Value {
	var val reflect.Value
	switch f := src.(type) {
	case reflect.Value:
		val = f
	default:
		val = reflect.ValueOf(src)
	}
	if val.Kind() == reflect.Interface {
		val = val.Elem()
		// if val is ptr, following to get Elem
	}
	if val.Kind() == reflect.Ptr {
		val = val.Elem()
	}
	return val
}

// 尝试提取 reflect.Value 中的值
//	value为简单类型时返回具体值，否则返回value自身
func ExtraReflectValue(value reflect.Value) interface{} {
	v1 := ToReflectValueFinal(value)
	switch f := v1; f.Kind() {
	case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
		return f.Int()
	case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64, reflect.Uintptr:
		return f.Uint()
	case reflect.String:
		return f.String()
	case reflect.Struct:
		if f.Type().ConvertibleTo(reflect.TypeOf(val_default_time_)) {
			if f.CanAddr() {
				ptr := f.Addr().Pointer()
				t := (*time.Time)(unsafe.Pointer(ptr))
				return t.Format(time.RFC3339Nano)
			}
		}
		return f
	//case reflect.Array, reflect.Slice:
	//case reflect.Map:
	//case reflect.Interface:
	default:
		return f
	}
}

func GetStructNameLower(value interface{}) []string {
	val := reflect.ValueOf(value)
	if val.Kind() == reflect.Ptr {
		val = val.Elem()
	}
	switch f := val; f.Kind() {
	case reflect.Struct:
		m := make([]string, 0, f.NumField())
		for i := 0; i < f.NumField(); i++ {
			field := f.Type().Field(i)
			if field.Name == "" {
				continue
			}
			m = append(m, strings.ToLower(field.Name))
		}
		return m

	default:
		return []string{}
	}
}

type null_io_t struct{}

func (ni *null_io_t) Write(p []byte) (n int, err error) {
	return len(p), nil
}
func (ni *null_io_t) Read(p []byte) (n int, err error) {
	return 0, nil
}
func (ni *null_io_t) Close() error {
	return nil
}
func (ni *null_io_t) Seek(offset int64, whence int) (int64, error) {
	return 0, nil
}

// 空io
var NullIo *null_io_t = &null_io_t{}

type rs_heap_item struct {
	rand_w float64
	idx    int
}

type rs_heap []*rs_heap_item

func (rsh rs_heap) Len() int { return len(rsh) }

func (rsh rs_heap) Less(i, j int) bool { return rsh[i].rand_w < rsh[j].rand_w }

func (rsh rs_heap) Swap(i, j int) { rsh[i], rsh[j] = rsh[j], rsh[i] }

func (rsh *rs_heap) Push(x interface{}) {
	*rsh = append(*rsh, x.(*rs_heap_item))
}

func (rsh *rs_heap) Pop() interface{} {
	old := *rsh
	n := len(old)
	rshi := old[n-1]
	*rsh = old[0 : n-1]
	return rshi
}

type ReservoirSamplingInterface interface {
	Len() int
	GetWeight(idx int) float64
}

func ReservoirSampleWeight(sample ReservoirSamplingInterface, res_len int, r *rand.Rand) []int {
	result := make([]int, res_len)
	sample_len := sample.Len()

	h := &rs_heap{}
	for i := 0; i < sample_len; i++ {
		rshi := &rs_heap_item{
			idx:    i,
			rand_w: math.Pow(r.Float64(), (1.0 / sample.GetWeight(i))),
		}
		if h.Len() < res_len {
			heap.Push(h, rshi)
		} else {
			if (*h)[0].rand_w < rshi.rand_w {
				heap.Pop(h)
				heap.Push(h, rshi)
			}
		}
	}

	res_idx := 0
	for h.Len() > 0 {
		rshi := heap.Pop(h).(*rs_heap_item)
		result[res_idx] = rshi.idx
		res_idx++
	}
	return result
}
