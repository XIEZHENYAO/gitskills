/*
	工具集

	Donnie.L
	2015.06
*/

package utility

import (
	"bufio"
	"bytes"
	"fmt"
	"io"
	"log"
	"regexp"
	"runtime"
	"runtime/pprof"
)

// 返回看当前内存heap对象数
func Lookup_heap_objs() int64 {
	p := pprof.Lookup("heap")
	//	p.WriteTo(os.Stdout, 2)
	buff := bytes.NewBuffer(make([]byte, 0))
	p.WriteTo(buff, 2)
	//	fmt.Println(buff.String())
	rx := regexp.MustCompile(`#\s*(HeapObjects)\s*=\s*(\d+)`)
	rd := bufio.NewReader(buff)
	for line, err := rd.ReadString('\n'); err == nil; line, err = rd.ReadString('\n') {
		l := len(line)
		if l > 0 {
			line = line[:l-1]
		}
		match := rx.FindStringSubmatch(line)
		if len(match) > 0 {
			//			fmt.Printf("%s: %s\n", match[1], match[2])
			return Int64(match[2])
		}
	}
	return 0
}

// 组织一个error，带[源文件：行号]格式的
func Errorf(format string, a ...interface{}) error {
	_, file, line, ok := runtime.Caller(1)
	if !ok {
		return fmt.Errorf(format, a...)
	}
	short := file
	for i := len(file) - 1; i > 0; i-- {
		if file[i] == '/' {
			short = file[i+1:]
			break
		}
	}
	file = short
	s := fmt.Sprintf(format, a...)
	return fmt.Errorf("[%s:%d]: %s", file, line, s)
}

func caller_shortfile(file string, lastsep_ ...rune) string {
	lastsep := '/'
	if len(lastsep_) > 0 {
		lastsep = lastsep_[0]
	}
	short := file
	for i := len(file) - 1; i > 0; i-- {
		if file[i] == byte(lastsep) {
			short = file[i+1:]
			break
		}
	}
	return short
}

// 将error重新封装，带上[源文件：行号]格式
func Error(err error) error {
	_, file, line, ok := runtime.Caller(1)
	if !ok {
		return err
	}
	file = caller_shortfile(file)
	return fmt.Errorf("[%s:%d]: %v", file, line, err)
}

// 将panci时routine调用堆栈打印到日志并退出
func LogPanicRoutineCallstack() {
	if e := recover(); e != nil {
		log.Println(e)
		lv := 3
		for {
			_, file, line, ok := runtime.Caller(lv)
			if !ok {
				break
			}
			file = caller_shortfile(file)
			log.Printf("%d) %s: %d\n", lv, file, line)
			lv++
		}
		log.Fatal("Fatal exit.")
	}
}

// 将routine调用堆栈打印到Writer
func WriteRoutineCallstack(lv int, wr io.Writer) {
	for {
		_, file, line, ok := runtime.Caller(lv)
		if !ok {
			break
		}
		file = caller_shortfile(file)
		s := fmt.Sprintf("%d) %s: %d\n", lv, file, line)
		wr.Write([]byte(s))
		lv++
	}
}
func WriteRoutineCallstackFull(lv int, wr io.Writer) {
	for {
		s := CallInfo(lv)
		if len(s) == 0 {
			break
		}
		s1 := fmt.Sprintf("%d) %s\n", lv, s)
		wr.Write([]byte(s1))
		lv++
	}
}

// 获取指定层调用者短文件名:行号组成的字符串
// lv=0是指本函数，1是调用本函数的调用者
func CallInfo(lv int) string {
	pc, file, line, ok := runtime.Caller(lv)
	if !ok {
		return ""
	}
	file = caller_shortfile(file)
	funcName := runtime.FuncForPC(pc).Name()
	funcName = caller_shortfile(funcName)
	fn := caller_shortfile(funcName, ')')
	// log.Println("callinfo ", fn)
	if len(fn) < len(funcName) {
		if len(fn) > 1 && fn[0] == '.' {
			fn = fn[1:]
		}
		funcName = fn
	} else {
		funcName = caller_shortfile(funcName, '.')
	}
	//	if strings.HasPrefix(funcName, workingDir) {
	//		funcName = funcName[len(workingDir):]
	//	}
	s := fmt.Sprintf("%s:%d(%s)", file, line, funcName)
	return s
}

func SimpleCallInfo(lv int) string {
	pc, file, _, ok := runtime.Caller(lv)
	if !ok {
		return ""
	}
	file = caller_shortfile(file)
	funcName := runtime.FuncForPC(pc).Name()
	funcName = caller_shortfile(funcName)
	fn := caller_shortfile(funcName, ')')
	if len(fn) < len(funcName) {
		if len(fn) > 1 && fn[0] == '.' {
			fn = fn[1:]
		}
		funcName = fn
	} else {
		funcName = caller_shortfile(funcName, '.')
	}
	s := fmt.Sprintf("%s(%s)", file, funcName)
	return s
}
