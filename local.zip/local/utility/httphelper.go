/*
	工具集 http助手

	Donnie.L
	2015.06
*/

package utility

import (
	"io/ioutil"
	"net/http"
	"net/url"
	"strings"
)

// 简易Get
func HttpGet(s_url string) (body []byte, statuscode int, err error) {
	resp, err := http.Get(s_url)
	if err != nil {
		return
	}

	defer resp.Body.Close()
	body, err = ioutil.ReadAll(resp.Body)
	statuscode = resp.StatusCode
	return
}
func HttpGets(s_url string) (string, int, error) {
	bs, st, err := HttpGet(s_url)
	return string(bs), st, err
}

// form get
func HttpFormGet(s_url string, mParam map[string]string) (body []byte, statuscode int, err error) {
	form := url.Values{}
	for k, v := range mParam {
		form.Set(k, v)
	}
	return HttpGet(s_url + "?" + form.Encode())
}
func HttpFormGets(s_url string, mParam map[string]string) (string, int, error) {
	bs, st, err := HttpFormGet(s_url, mParam)
	return string(bs), st, err
}

// 简易Post
func HttpPost(s_url string, params string) (body []byte, statuscode int, err error) {
	resp, err := http.Post(
		s_url,
		"application/x-www-form-urlencoded",
		strings.NewReader(params))
	if err != nil {
		return
	}

	defer resp.Body.Close()
	body, err = ioutil.ReadAll(resp.Body)
	statuscode = resp.StatusCode
	return
}
func HttpPosts(s_url string, params string) (string, int, error) {
	bs, st, err := HttpPost(s_url, params)
	return string(bs), st, err
}

// form post
func HttpFormPost(s_url string, mParam map[string]string) (body []byte, statuscode int, err error) {
	hc := http.Client{}

	form := url.Values{}
	for k, v := range mParam {
		form.Set(k, v)
	}
	req, err := http.NewRequest("POST", s_url, strings.NewReader(form.Encode()))
	if err != nil {
		return
	}
	req.Header.Add("Content-Type", "application/x-www-form-urlencoded")
	resp, err := hc.Do(req)
	if err != nil {
		return
	}

	defer resp.Body.Close()
	body, err = ioutil.ReadAll(resp.Body)
	statuscode = resp.StatusCode
	return
}
func HttpFormPosts(s_url string, mParam map[string]string) (string, int, error) {
	bs, st, err := HttpFormPost(s_url, mParam)
	return string(bs), st, err
}
