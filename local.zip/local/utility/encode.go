/*
	简易工具：压缩/解压缩/编码/解码
*/

package utility

import (
	"bytes"
	"compress/zlib"
	"encoding/base64"
	"encoding/binary"
	"io"
	"local/des-ecb"
	"math/rand"
	"time"
)

// 用zlib压缩
func ZlibEncode(src []byte) []byte {
	var bf bytes.Buffer
	//	w := zlib.NewWriter(&bf)
	w, err := zlib.NewWriterLevel(&bf, zlib.BestCompression)
	if err != nil {
		return []byte("")
	}
	w.Write(src)
	w.Close()
	return bf.Bytes()
}

// 用zlib解压缩
func ZlibDecode(src []byte) ([]byte, error) {
	br := bytes.NewReader(src)
	var out bytes.Buffer
	r, err := zlib.NewReader(br)
	if err != nil {
		return nil, err
	}
	io.Copy(&out, r)
	r.Close()
	return out.Bytes(), nil
}

// zlib压缩->base64编码
//	ZlibBase64Encode(src) use stander base64-encoding
//	or ZlibBase64Encode(src, base64.URLEncoding)  use url-base64-encoding
func ZlibBase64Encode(src []byte, custom_b64enc ...*base64.Encoding) []byte {
	b64enc := base64.StdEncoding
	if len(custom_b64enc) > 0 {
		b64enc = custom_b64enc[0]
	}
	var bf bytes.Buffer
	w0 := base64.NewEncoder(b64enc, &bf)
	w, err := zlib.NewWriterLevel(w0, zlib.BestCompression)
	if err != nil {
		return []byte("")
	}
	w.Write(src)
	w.Close()
	w0.Close()
	return bf.Bytes()
}

// base64解码->zlib解压
func Base64ZlibDecode(src []byte, custom_b64enc ...*base64.Encoding) ([]byte, error) {
	b64enc := base64.StdEncoding
	if len(custom_b64enc) > 0 {
		b64enc = custom_b64enc[0]
	}
	br := bytes.NewReader(src)
	b64 := base64.NewDecoder(b64enc, br)
	var out bytes.Buffer
	r, err := zlib.NewReader(b64)
	if err != nil {
		return nil, err
	}
	io.Copy(&out, r)
	r.Close()
	return out.Bytes(), nil
}

func Base64Encode(src []byte, custom_b64enc ...*base64.Encoding) []byte {
	b64enc := base64.StdEncoding
	if len(custom_b64enc) > 0 {
		b64enc = custom_b64enc[0]
	}
	var bf bytes.Buffer
	w0 := base64.NewEncoder(b64enc, &bf)
	w0.Write(src)
	w0.Close()
	return bf.Bytes()
}
func Base64Decode(src []byte, custom_b64enc ...*base64.Encoding) []byte {
	b64enc := base64.StdEncoding
	if len(custom_b64enc) > 0 {
		b64enc = custom_b64enc[0]
	}
	br := bytes.NewReader(src)
	b64 := base64.NewDecoder(b64enc, br)
	var out bytes.Buffer
	io.Copy(&out, b64)
	return out.Bytes()
}

// 包0协议 打包
// 压缩 > 加密？ > base64
// pwd为8字节启用加密
func Pack0Encode(src []byte, pwd []byte) []byte {
	// 压缩
	s1 := ZlibEncode(src)
	//	fmt.Println("s0 ", len(s0))
	// 是否加密
	if len(pwd) == 8 {
		//		var err error
		s1, _ = ldes.Des_ecb_encrypt_pkcs5(s1, pwd)
	}
	//	fmt.Println("des ", len(s1))
	// base64
	return Base64Encode(s1)
}

// 包0协议 解包
// base64 > 解密？ > 解压
// pwd为8字节启用解密
func Pack0Decode(src []byte, pwd []byte) []byte {
	s1 := Base64Decode(src)
	if len(s1) == 0 || len(s1)%8 != 0 {
		return []byte{}
	}
	// 是否解密
	if len(pwd) == 8 {
		s1, _ = ldes.Des_ecb_decrypt_pkcs5(s1, pwd)
	}
	// 解压
	s1, _ = ZlibDecode(s1)
	return s1
}

// 包1协议 打包
// 压缩？ > 加密？ > base64
// src超过sz_cmp_bound字节启用压缩，pwd为8字节启用加密
// 加密/base64 前的字符串被添加了4字节的littleEndian前缀，0表示未压缩，否则表示压缩前大小
func Pack1Encode(src []byte, pwd []byte, sz_cmp_bound int) []byte {
	var s0 []byte
	// 是否压缩
	var n int
	if len(src) > sz_cmp_bound {
		n = len(src)
		s0 = ZlibEncode(src)
	} else {
		s0 = src
	}
	//	fmt.Println("s0 ", len(s0))
	s1 := make([]byte, 4, len(s0)+4)
	binary.LittleEndian.PutUint32(s1, uint32(n))
	s1 = append(s1, s0...)
	//	fmt.Println("s1 ", len(s1))
	// 是否加密
	if len(pwd) == 8 {
		//		var err error
		s1, _ = ldes.Des_ecb_encrypt_pkcs5(s1, pwd)
		//		fmt.Println(err)
	}
	//	fmt.Println("des ", len(s1))
	// base64
	return Base64Encode(s1)
}

// 包1协议 解包
// base64 > 解密？ > 解压？
// pwd为8字节启用解密
// 解密/debase64 前的字符串被添加了4字节的littleEndian前缀，0表示未压缩，否则表示压缩前大小
func Pack1Decode(src []byte, pwd []byte) []byte {
	s1 := Base64Decode(src)
	if len(s1) == 0 || len(s1)%8 != 0 {
		return []byte{}
	}
	// 是否解密
	if len(pwd) == 8 {
		s1, _ = ldes.Des_ecb_decrypt_pkcs5(s1, pwd)
	}
	// 是否解压
	if len(s1) < 4 {
		return []byte{}
	}
	n := binary.LittleEndian.Uint32(s1)
	s1 = s1[4:]
	if n > 0 {
		// 需要解压
		s1, _ = ZlibDecode(s1)
		if s1 == nil || len(s1) != int(n) {
			return []byte{} // 解压失败
		}
	}
	return s1
}

// 生成指定长度随机密码
func GenRandPassword(l int) []byte {
	str := "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
	bytes := []byte(str)
	result := make([]byte, 0, l)
	r := rand.New(rand.NewSource(time.Now().UnixNano()))
	for i := 0; i < l; i++ {
		result = append(result, bytes[r.Intn(len(bytes))])
	}
	return result
}
