package searchpath

import (
	"local/searchpath/astar"
)

const (
	UP        = iota //向上
	RIGHT            //向右
	DOWN             //向下
	LEFT             //向左
	UPRIGHT          //向右上角
	RIGHTDOWN        //右下角
	DOWNLEFT         //向左下角
	LEFTUP           //向左上角
)

type Navigater interface {
	//获取(x,y)点在dir方向上的相邻点，不存在时返回(-1,-1)
	DirToNode(x, y, dir int) (int, int)
	//获取(x,y)点支持的最大方向数4/8
	GetMaxDirs(x, y int) int
	//获取(x,y)点是否是不可通过的障碍物
	IsBlock(x, y int) bool
	//获取(x0,y0)点到(x1,y1)点的资源消耗量 (x0,y0)点和(x1,y1)点是相邻点
	GetCost(x0, y0, x1, y1 int) int
	//获取(x0,y0)点到(x1,y1)点的预估资源消耗值
	EstimatedCost(x0, y0, x1, y1 int) int
}

type Tile struct {
	X, Y int
	Ngr  Navigater
}

func (this *Tile) PathGetId() int64 {
	return int64(this.Y*1000000 + this.X)
}

func (this *Tile) PathNeighbors() []astar.Pather {
	neighbors := []astar.Pather{}
	maxDir := this.Ngr.GetMaxDirs(this.X, this.Y)
	for index := 0; index < maxDir; index++ {
		x, y := this.Ngr.DirToNode(this.X, this.Y, index)
		if !this.Ngr.IsBlock(x, y) {
			t := setTile(x, y, this.Ngr)
			neighbors = append(neighbors, t)
		}
	}
	return neighbors
}

func (this *Tile) PathNeighborCost(to astar.Pather) float64 {
	toT := to.(*Tile)
	cost := this.Ngr.GetCost(this.X, this.Y, toT.X, toT.Y)
	return float64(cost)
}

func (t *Tile) PathEstimatedCost(to astar.Pather) float64 {
	return float64(t.Ngr.EstimatedCost(t.X, t.Y, to.(*Tile).X, to.(*Tile).Y))
}

func setTile(x, y int, ngr Navigater) *Tile {
	return &Tile{X: x, Y: y, Ngr: ngr}
}

//路径搜索 起始点(sX, sY) 终点(eX, eY)
func SearchPath(sX, sY, eX, eY int, ngr Navigater) [][2]int {
	from := setTile(sX, sY, ngr)
	to := setTile(eX, eY, ngr)
	if true {
		path, _, found := astar.Path(from, to)
		respath := [][2]int{}
		if found {
			for _, p := range path {
				t := p.(*Tile)
				respath = append(respath, [2]int{t.X, t.Y})
			}
		}
		return respath
	}
	return [][2]int{}
}
