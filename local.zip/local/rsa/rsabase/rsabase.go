package rsabase

import (
	"errors"
	"local/rsa"
)

/*
func RsaBaseEncodeString(pkg, key string, model int) (string, error) {
	RSA := rsa.NewRSASecurity()
	switch model {
	case rsa.MODE_PRIKEY_ENCRYPT:
		err := RSA.PriInit(key)
		if err != nil {
			return "", err
		}
	case rsa.MODE_PUBKEY_ENCRYPT:
		err := RSA.PubInit(key)
		if err != nil {
			return "", err
		}
	default:
		return "", errors.New("mode error")
	}
	return RSA.String(pkg, model)
}

func RsaBaseDecodeString(pkg, key string, model int) (string, error) {
	RSA := rsa.NewRSASecurity()
	switch model {
	case rsa.MODE_PRIKEY_DECRYPT:
		err := RSA.PriInit(key)
		if err != nil {
			return "", err
		}
	case rsa.MODE_PUBKEY_DECRYPT:
		err := RSA.PubInit(key)
		if err != nil {
			return "", err
		}
	default:
		return "", errors.New("mode error")
	}
	return RSA.String(pkg, model)
}
*/
func RsaBaseEncodeBytes(pkg []byte, key string, model int) ([]byte, error) {
	RSA := rsa.NewRSASecurity()
	switch model {
	case rsa.MODE_PRIKEY_ENCRYPT:
		err := RSA.PriInit(key)
		if err != nil {
			return []byte{}, err
		}
	case rsa.MODE_PUBKEY_ENCRYPT:
		err := RSA.PubInit(key)
		if err != nil {
			return []byte{}, err
		}
	default:
		return []byte{}, errors.New("mode error")
	}
	return RSA.Byte(pkg, model)
}

func RsaBaseDecodeBytes(pkg []byte, key string, model int) ([]byte, error) {
	RSA := rsa.NewRSASecurity()
	switch model {
	case rsa.MODE_PRIKEY_DECRYPT:
		err := RSA.PriInit(key)
		if err != nil {
			return []byte{}, err
		}
	case rsa.MODE_PUBKEY_DECRYPT:
		err := RSA.PubInit(key)
		if err != nil {
			return []byte{}, err
		}
	default:
		return []byte{}, errors.New("mode error")
	}
	return RSA.Byte(pkg, model)
}
