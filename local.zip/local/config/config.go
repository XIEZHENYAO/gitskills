package config

import (
	Lu "local/utility"
	"local/xml"
)

const (
	INT           = 1
	FLOAT         = 2
	STRING        = 3
	DEFAULT_INT   = 0
	DEFAULT_FLOAT = 1
	DEFAULT_STR   = ""
)

var CFG *xml.Node

func LoadXml(file string) {
	CFG = xml.Open(file)
}

func return_zero(re_type int) interface{} {
	switch re_type {
	case INT:
		return DEFAULT_INT
	case FLOAT:
		return DEFAULT_FLOAT
	case STRING:
		return DEFAULT_STR
	default:
		return ""
	}
}

func return_val(val string, re_type int) interface{} {
	switch re_type {
	case INT:
		return Lu.Int(val)
	case FLOAT:
		return Lu.Float64(val)
	case STRING:
		return Lu.Str(val)
	default:
		return ""
	}
}

func Get(path string, re_type int) interface{} {
	x, _ := CFG.GetElements(path)
	if len(x) == 0 {
		return return_zero(re_type)
	}
	return return_val(x[0].GetValue(), re_type)
}

func GetAttr(path string, attr string, re_type int) interface{} {
	x, _ := CFG.GetElements(path)
	if len(x) == 0 {
		return return_zero(re_type)
	}
	attrs := x[0].Attr
	v, ok := attrs[attr]
	if ok {
		return return_val(v, re_type)
	} else {
		return return_zero(re_type)
	}
}

func Gets(path string) []*xml.Node {
	x, err := CFG.GetElements(path)
	if err != nil {
		return make([]*xml.Node, 0)
	}
	return x
}
