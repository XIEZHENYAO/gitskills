/*
	连接管理器: 广播队列

	Donnie.L
	2015.06
*/

package connmgr

import (
	"log"
	"sync"
	"time"
)

/*





	广播服务
*/
type broadcast_t struct {
	ch_add   chan chan []byte
	ch_del   chan chan []byte // delete only
	ch_close chan chan []byte // delete and close channel
	ch_msg   chan []byte
	v_all    []chan []byte
	idx_que  int
}

func (brd *broadcast_t) del_trans_chan(ch chan []byte) {
	lenv := len(brd.v_all)
	for i := 0; i < lenv; i++ {
		if brd.v_all[i] == ch {
			if i != lenv-1 {
				brd.v_all[i] = brd.v_all[lenv-1]
			}
			brd.v_all = brd.v_all[:lenv-1]
			break
		}
	}
}

type broadcast_service_t struct {
	que     []broadcast_t
	lock    sync.Mutex
	n_alloc int
	mgr     *ConnMgr
}

func (svc *broadcast_service_t) init(n_que, cap_conn int, mgr *ConnMgr) {
	svc.mgr = mgr
	svc.que = make([]broadcast_t, n_que)
	for i := 0; i < len(svc.que); i++ {
		brd := &svc.que[i]
		brd.v_all = make([]chan []byte, 0, cap_conn)
		brd.ch_add = make(chan chan []byte, svc.mgr.cfg.PreSizeChan)
		brd.ch_del = make(chan chan []byte, svc.mgr.cfg.PreSizeChan)
		brd.ch_close = make(chan chan []byte, svc.mgr.cfg.PreSizeChan)
		brd.ch_msg = make(chan []byte, svc.mgr.cfg.PreSizeChan*10)
		brd.idx_que = i
		go svc.broadcast_service(i)
	}
	svc.n_alloc = 0
}

func (svc *broadcast_service_t) add_chan(ch chan []byte) {
	for i := 0; i < len(svc.que); i++ {
		svc.que[i].ch_add <- ch
	}
}

// 删除并关闭转发chan
//	从最后一个队列开始删除，并传递到上一个队列，直到队列0负责关闭该chan
func (svc *broadcast_service_t) close_chan(ch chan []byte) {
	svc.que[len(svc.que)-1].ch_close <- ch
}

// 删除转发chan
func (svc *broadcast_service_t) del_chan(ch chan []byte) {
	for i := 0; i < len(svc.que); i++ {
		svc.que[i].ch_del <- ch
	}
}

func (svc *broadcast_service_t) broadcast_chan() chan []byte {
	lenque := len(svc.que)
	svc.lock.Lock()
	idx := svc.n_alloc
	svc.n_alloc++
	if svc.n_alloc >= lenque {
		svc.n_alloc = 0
	}
	svc.lock.Unlock()
	return svc.que[idx].ch_msg
}

func (svc *broadcast_service_t) broadcast_service(idx int) {
	brd := &svc.que[idx]
	for {
		select {
		case ch := <-brd.ch_add:
			brd.v_all = append(brd.v_all, ch)
			//			log.Printf("broad que add %v\n", brd.v_all)
		case ch := <-brd.ch_del:
			brd.del_trans_chan(ch)
			//			log.Printf("broad que del %v\n", brd.v_all)
		case ch := <-brd.ch_close:
			brd.del_trans_chan(ch)
			// 传递到上个队列，第0个负责关闭
			if brd.idx_que > 0 {
				svc.que[brd.idx_que-1].ch_close <- ch
			} else {
				// channel可能会被外部保存，关闭有风险，等待GC
				//				close(ch)
				//				log.Println("close trans chan.", brd.idx_que, ch)
			}
			//			log.Printf("broad que del %d: %v\n", brd.idx_que, brd.v_all)
		case msg := <-brd.ch_msg:
			n := 0
			for i := 0; i < len(brd.v_all); i++ {
				if svc.mgr.cfg.DropOnUserBroadcastFull == 0 {
					select {
					case brd.v_all[i] <- msg:
					case <-time.After(time.Microsecond * time.Duration(svc.mgr.cfg.TimeoutBroadcast)):
					}
				} else {
					select {
					case brd.v_all[i] <- msg:
					default:
					}
				}
			}
			if n > 0 {
				log.Printf("svc broadcast: lose %d\n", n)
			}
		}
	}

}
