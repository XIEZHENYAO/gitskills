/*
	连接属性

	Donnie.L
	2015.06
*/

package connmgr

import (
	"fmt"
	"local/conn"
	"log"
	"time"
)

/*




	单个连接数据结构
*/
type ConnInfo struct {
	conn           conn.ConnType
	userid         uint64      // >0有效
	sid            string      // len>0有效
	chan_msg_in    chan []byte // 消息in
	chan_msg_trans chan []byte // 转发给我的客户端消息
	chan_cmd       chan SysCmd // 服务器发给我的消息(指令)
	isBroken       bool        // 连接是否中断了
	time_broken    time.Time   // 断线时间，仅isBroken为true有效
	isCleaning     bool        //连接数据结构正在清理中
	mgr            *ConnMgr
	idx_conn       int
}

func (c *ConnInfo) init(initInfo *init_conn_t, mgr *ConnMgr, idx_conn int) {
	c.conn = initInfo.conn
	c.userid = 0
	c.sid = ""
	if initInfo.chan_msg_in != nil {
		c.chan_msg_in = initInfo.chan_msg_in
		c.chan_msg_trans = make(chan []byte, mgr.cfg.PreSizeChan)
		c.chan_cmd = make(chan SysCmd, 10*mgr.cfg.PreSizeChan)
	} else {
		// channel的关闭有很大风险，可能谁保存了该channel，关闭会导致crash，暂不主动关闭，等待GC
		//		if c.chan_msg_in != nil {
		//			close(c.chan_msg_in)
		//		}
		//		if c.chan_cmd != nil {
		//			close(c.chan_cmd)
		//		}
		// chan_msg_trans绝对不能在此关闭
		//		if c.chan_msg_trans != nil {
		//			close(c.chan_msg_trans)
		//		}
		c.chan_msg_in = nil
		c.chan_msg_trans = nil
		c.chan_cmd = nil
	}
	c.isBroken = true
	c.isCleaning = false
	c.mgr = mgr
	c.idx_conn = idx_conn
}
func (c *ConnInfo) IsUsed() bool {
	return c.conn != nil
}

// 注册用户信息到队列中，占用索引。注册是异步的，用户协程收到 CMD_REG_USER_OK 系统消息后 GetUserid() 等才可用
func (c *ConnInfo) RegUserInfo(userid uint64, sid string) {
	//	c.userid = userid
	//	c.sid = sid
	ui := userinfo_reg_t{c.conn, userid, sid}
	c.mgr.chan_reg_user <- ui
}
func (c *ConnInfo) GetConn() conn.ConnType {
	return c.conn
}
func (c *ConnInfo) GetConnMgr() *ConnMgr {
	return c.mgr
}
func (c *ConnInfo) GetUserid64() uint64 {
	return c.userid
}
func (c *ConnInfo) GetUserid() uint {
	return uint(c.userid)
}
func (c *ConnInfo) GetSid() string {
	return c.sid
}
func (c *ConnInfo) GetConnIdx() int {
	return c.idx_conn
}
func (c *ConnInfo) IsBroken() bool {
	return c.isBroken
}
func (c *ConnInfo) GetBrokenTime() time.Time {
	return c.time_broken
}

func (c *ConnInfo) QueDesc() string {
	return fmt.Sprintf("[user #%d: %d,%s]", c.idx_conn, c.userid, c.sid)
}

//  接收客户端给我的消息队列
func (c *ConnInfo) Chan_msg_in() <-chan []byte {
	return c.chan_msg_in
}

// 接收转发给我的客户端的消息队列
func (c *ConnInfo) Chan_msg_trans() <-chan []byte {
	return c.chan_msg_trans
}

// 接收系统消息队列
func (c *ConnInfo) Chan_cmd() chan SysCmd {
	return c.chan_cmd
}

// 通知管理器退出退列
func (c *ConnInfo) ExitConnQueue() {
	c.isCleaning = true
	c.mgr.chan_del_conn <- c.conn
}

// 发送消息给对方，文本
func (c *ConnInfo) SendMsg(s string) error {
	conn := c.conn
	if c.IsBroken() || conn == nil {
		return nil
	}
	return conn.Send(s)
}

// 发送消息给对方，二进制
func (c *ConnInfo) SendBytes(bs []byte) error {
	return c.conn.Send(bs)
}

// 广播
func (c *ConnInfo) Broadcast(msg []byte) {
	select {
	case c.mgr.broadcast_svc.broadcast_chan() <- msg:
	case <-time.After(time.Microsecond * time.Duration(c.mgr.cfg.TimeoutBroadcast*100)):
		if c.mgr.cfg.LogQueue > 0 {
			log.Printf("%s broadcast timeout\n", c.conn.RemoteAddr())
		}
	}
}

// 推送消息给我的协程处理
// smsg - 消息体，由调用者跟消息处理器约定格式，string or []byte
// ext - 参见 connmgr.PushMsgToUid 中ext的解释
func (c *ConnInfo) PushMsg(smsg interface{}, ext ...interface{}) {
	v := make([]interface{}, 2, 2+len(ext))
	v[0] = c.GetUserid()
	v[1] = smsg
	if len(ext) > 0 {
		v = append(v, ext...)
	}
	p := SysCmd{Id: CMD_MSGTO_UID, Param: v}
	select {
	case c.chan_cmd <- p:
	default:
	}
}

type userinfo_reg_t struct {
	conn   conn.ConnType
	userid uint64
	sid    string
}

type init_conn_t struct {
	conn        conn.ConnType
	chan_msg_in chan []byte
}
