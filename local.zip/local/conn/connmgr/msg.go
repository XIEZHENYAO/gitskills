package connmgr

/*
	连接管理器 连接消息ID范围： [100-200)
*/
const (
	CMD_NET_BROKEN  = 100
	CMD_FORCE_EXIT  = 105
	CMD_REG_USER_OK = 110
	CMD_NET_REPLACE = 120 // 网络重连成功，Param:0-原先未掉线， 1-原先为掉线状态

	CMD_QUE_STAT    = 150 // 统计信息，Param=[map[string]interface{}_channel]
	CMD_MSGTO_UID   = 155 // Push网络消息给指定uid, Param=[uid,net-msg[,io.Writer,chan int(wait)]]
	CMD_QUERY_UID   = 160 // 获取UID链接信息 Param=[uid,chan ConnInfo]
	CMD_MSGTO_CONN  = 165 // Push网络消息给指定ConnType连接, Param=[Conn, net-msg]
	CMD_QUE_PLY_NUM = 170 // 查询当前玩家数量 Param[chan int]
	CMD_SHUTDOWN    = 175 // 关闭服务，踢出所有客户端, CMD_FORCE_EXIT
)

//CMD_KICKOUT_KEEP = 152 // 踢出指定uid并持续一段时间不能登录
