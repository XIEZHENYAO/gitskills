/*
	websocket/socket连接管理器
	websocket连接管理器
		用队列管理websocket连接及其基本信息，维护索引
		建立连接与用户的关联
		注意：当连接中断时并不直接删除连接数据，需要用户协程决定
	例：
		mgr := connmgr.NewConnMgr(100, 1, func(ci *connmgr.ConnInfo) {
			fmt.Printf("%+v\n", *ci)
			for {
				select {
				case s := <-ci.Chan_msg_in():
					fmt.Println(len(s))
				case cmd := <-ci.Chan_cmd():
					if cmd.Id == connmgr.CMD_NET_BROKEN {
						ci.ExitConnQueue()
						return
					}
				}
			}
		})
		http.Handle("/server", websocket.Handler(mgr.GetWsHandler()))
		...http listen...

	Donnie.L
	2015.06
*/

package connmgr

import (
	"fmt"
	"io"
	"local/conn"
	"log"
	"net"
	"net/http"
	"time"

	"code.google.com/p/go.net/websocket"
)

// 系统指令结构
type SysCmd struct {
	Id    int
	Param interface{}
}

// 启动用户协程的函数
type StartUserRoutine func(*ConnInfo)

// 队列遍历回调
type QueueIterateCallBack func(*ConnInfo)

/*





	连接管理器
*/
type ConnMgr struct {
	// 配置
	cfg *ConnCfg
	// 单元地址在运行期不变
	v_conn      []ConnInfo
	alloc_index int                   // 新位置从哪开始申请
	idle_index  []int                 // 回收的空闲位置
	indexConn   map[conn.ConnType]int // ConnType->index of v_conn
	indexSid    map[string]int        // sid->index of v_conn
	indexUid    map[uint64]int        // userid->index of v_conn
	//
	chan_add_conn     chan init_conn_t          // 注册新连接的队列
	chan_del_conn     chan conn.ConnType        // 注销连接的队列
	chan_brk_conn     chan conn.ConnType        // 连接中断通知队列
	chan_reg_user     chan userinfo_reg_t       // 注册用户信息的队列，用于做索引
	chan_cmd          chan SysCmd               // 发给我的消息(指令)
	chan_queIterateCb chan QueueIterateCallBack // 队列遍历回调
	broadcast_svc     broadcast_service_t       // 全范围广播服务
	//
	n_conn  int // 有效连接数
	n_login int // 有效登录数
	//
	funcStartUserRoutine StartUserRoutine
	//
	stop_accept_conn bool
}

func NewConnMgr(cfg *ConnCfg, f StartUserRoutine) *ConnMgr {
	var cm ConnMgr
	cm.cfg = cfg
	cm.v_conn = make([]ConnInfo, 0, cfg.Cap_que) // 事先分配空间，保证每个单元地址在运行期不变
	cm.idle_index = make([]int, 0, cap(cm.v_conn))
	cm.alloc_index = 0
	cm.indexConn = make(map[conn.ConnType]int, cfg.PreSizeConnIndex)
	cm.indexSid = make(map[string]int, cfg.PreSizeConnIndex)
	cm.indexUid = make(map[uint64]int, cfg.PreSizeConnIndex)
	cm.chan_add_conn = make(chan init_conn_t, cfg.PreSizeChan)
	cm.chan_del_conn = make(chan conn.ConnType, cfg.PreSizeChan)
	cm.chan_brk_conn = make(chan conn.ConnType, cfg.PreSizeChan)
	cm.chan_reg_user = make(chan userinfo_reg_t, cfg.PreSizeChan)
	cm.chan_cmd = make(chan SysCmd, cfg.PreSizeChan*20)
	cm.chan_queIterateCb = make(chan QueueIterateCallBack, cfg.PreSizeChan)
	cm.n_conn = 0
	cm.n_login = 0
	cm.funcStartUserRoutine = f
	cm.stop_accept_conn = false
	go cm.service()
	cm.broadcast_svc.init(cfg.Broadcast_rouine, cfg.Cap_que, &cm)
	return &cm
}

func (mgr *ConnMgr) service() {
	for {
		select {
		case wi := <-mgr.chan_add_conn:
			ci := mgr.add_conn(&wi)
			if ci != nil {
				go mgr.funcStartUserRoutine(ci)
				if mgr.cfg.LogQueue > 0 {
					log.Printf("%s alloc queue index %s", ci.conn.RemoteAddr(), ci.QueDesc())
				}
			}
		case conn_del := <-mgr.chan_del_conn: // 由用户协程通知
			if mgr.cfg.LogQueue > 0 {
				s := fmt.Sprintf("%s exit from queue", conn_del.RemoteAddr())
				if idx, ok := mgr.indexConn[conn_del]; ok {
					s = s + " " + mgr.v_conn[idx].QueDesc()
				}
				log.Println(s)
			}
			mgr.del_conn(conn_del)
		case conn_brk := <-mgr.chan_brk_conn: // 由websocket handler通知
			if idx, ok := mgr.indexConn[conn_brk]; ok {
				conn := &mgr.v_conn[idx]
				// 标记断线
				conn.isBroken = true
				conn.time_broken = time.Now()
				// 通知用户协程
				cmd := SysCmd{Id: CMD_NET_BROKEN}
				select {
				case conn.chan_cmd <- cmd:
				default:
				}
				if mgr.cfg.LogQueue > 0 {
					log.Printf("%s net broken, %s", conn.conn.RemoteAddr(), conn.QueDesc())
				}
				// 通知广播服务不再转发给此客户端
				mgr.broadcast_svc.del_chan(conn.chan_msg_trans)
			}
		case ui := <-mgr.chan_reg_user:
			if ui.userid == 0 {
				continue
			}
			if idx, ok := mgr.indexConn[ui.conn]; ok {
				if idx0, ok := mgr.indexUid[ui.userid]; ok {
					if idx == idx0 {
						// 自己重复登录？
						continue
					}
					// 已在线，根据 ConnCfg.ReLoginDeal 处理
					if mgr.cfg.ReLoginDeal == 0 || mgr.v_conn[idx0].isCleaning {
						//	都踢下线,已在线的提示为已在其他地方登录，新连接提示为重新连接再次尝试登录
						cmd := SysCmd{Id: CMD_FORCE_EXIT, Param: 1}
						select {
						case mgr.v_conn[idx0].chan_cmd <- cmd:
						default:
							log.Printf("%s chan_cmd busy in ReLoginDeal.", mgr.v_conn[idx0].QueDesc())
						}
						cmd.Param = 2
						select {
						case mgr.v_conn[idx].chan_cmd <- cmd:
						default:
							log.Printf("%s chan_cmd busy in ReLoginDeal.", mgr.v_conn[idx].QueDesc())
						}
						if mgr.cfg.LogQueue > 0 {
							log.Printf("%s DUPLICATE-LOGIN at %s, force exit all.", mgr.v_conn[idx0].QueDesc(), mgr.v_conn[idx].QueDesc())
						}
					} else if mgr.cfg.ReLoginDeal != 0 {
						// 替换原位置中的连接，继续服务(保留old_c，new_c准备关闭)
						old_c := &mgr.v_conn[idx0]
						new_c := &mgr.v_conn[idx]
						if mgr.cfg.LogQueue > 0 {
							log.Printf("%s NET-REPLACE, old-net: %s, new-net: %s, old-is-broken: %v", old_c.QueDesc(), old_c.conn.RemoteAddr(), new_c.conn.RemoteAddr(), old_c.isBroken)
						}
						is_old_broken := 0
						if old_c.isBroken {
							is_old_broken = 1
						}
						//fmt.Printf("before conn exchange: old=%#v, new=%#v", old_c, new_c)
						new_c.userid = 0
						new_c.sid = ""
						// 交换conn索引 indexConn
						mgr.indexConn[new_c.conn] = idx0
						mgr.indexConn[old_c.conn] = idx
						// 交换 chan_msg_in
						new_c.chan_msg_in, old_c.chan_msg_in = old_c.chan_msg_in, new_c.chan_msg_in
						// 交换 conn
						new_c.conn, old_c.conn = old_c.conn, new_c.conn
						// old 标记非断线
						old_c.isBroken = false
						//fmt.Printf("after conn exchange: old=%#v, new=%#v", old_c, new_c)
						// 通知 new_c 用户协程关闭
						select {
						case new_c.chan_cmd <- SysCmd{Id: CMD_FORCE_EXIT, Param: 3}:
						default:
							log.Printf("%v_%v NET-REPLACE, CMD_FORCE_EXIT push failed CHANNEL BUSY. (length:%v)", new_c.QueDesc(), new_c.conn.RemoteAddr(), len(new_c.chan_cmd))
						}
						// 通知 old_c 网络重连成功
						select {
						case old_c.chan_cmd <- SysCmd{Id: CMD_NET_REPLACE, Param: is_old_broken}:
						default:
							log.Printf("%v_%v NET-REPLACE, CMD_FORCE_EXIT push failed CHANNEL BUSY. (length:%v)", old_c.QueDesc(), old_c.conn.RemoteAddr(), len(old_c.chan_cmd))
						}
					}
					continue
				}
				mgr.indexUid[ui.userid] = idx
				if len(ui.sid) > 0 {
					mgr.indexSid[ui.sid] = idx
				}
				conn := &mgr.v_conn[idx]
				conn.userid = ui.userid
				conn.sid = ui.sid
				mgr.n_login++
				// 通知用户协程注册完成
				cmd := SysCmd{Id: CMD_REG_USER_OK}
				select {
				case conn.chan_cmd <- cmd:
				default:
				}
				//
				if mgr.cfg.LogQueue > 0 {
					log.Printf("%s bind to %s", conn.conn.RemoteAddr(), conn.QueDesc())
				}
			}
		case cmd := <-mgr.chan_cmd:
			switch cmd.Id {
			case CMD_QUE_STAT:
				v, ok := cmd.Param.([]interface{})
				if !ok || len(v) < 1 {
					break
				}
				c, ok := v[0].(chan map[string]interface{})
				if !ok {
					break
				}
				m := make(map[string]interface{}, 5)
				m["n_conn"] = mgr.n_conn
				m["n_login"] = mgr.n_login
				v1 := make([][]interface{}, 0, mgr.n_conn)
				for idx, conn := range mgr.v_conn {
					if !conn.IsUsed() {
						continue
					}
					v1 = append(v1, []interface{}{idx, conn.GetUserid64(), conn.GetSid(), conn.GetConn().RemoteAddr()})
				}
				m["v"] = v1
				select {
				case c <- m:
				default:
				}
			case CMD_MSGTO_UID:
				v, ok := cmd.Param.([]interface{})
				if !ok || len(v) < 2 {
					break
				}
				uid, ok1 := v[0].(uint)
				if !ok1 {
					break
				}
				idx, ok := mgr.indexUid[uint64(uid)]
				if !ok {
					if len(v) >= 4 {
						if w, ok := v[2].(io.Writer); ok {
							fmt.Fprintf(w, "uid %d not found.\n", uid)
						}
						if wait, ok := v[3].(chan int); ok {
							select {
							case wait <- -1:
							default:
							}
						}
					}
					break
				}
				select {
				case mgr.v_conn[idx].chan_cmd <- cmd:
				default:
				}

			case CMD_QUERY_UID:
				v, ok := cmd.Param.([]interface{})
				if !ok || len(v) < 2 {
					break
				}
				wait_ch, ok := v[1].(chan *ConnInfo)
				if !ok {
					break
				}
				for i, val := range v {
					if i == 1 {
						continue
					}
					var c *ConnInfo
					for {
						uid, ok1 := val.(uint64)
						if !ok1 {
							break
						}
						idx, ok := mgr.indexUid[uid]
						if ok {
							c = &mgr.v_conn[idx]
						}
						break
					}
					select {
					case wait_ch <- c:
					default:
					}
				}
			case CMD_MSGTO_CONN:
				v, ok := cmd.Param.([]interface{})
				if !ok || len(v) < 2 {
					break
				}
				conn, ok1 := v[0].(conn.ConnType)
				if !ok1 {
					break
				}
				idx, ok := mgr.indexConn[conn]
				if !ok {
					break
				}
				select {
				case mgr.v_conn[idx].chan_cmd <- cmd:
				default:
				}
			case CMD_QUE_PLY_NUM:
				v, ok := cmd.Param.([]interface{})
				if !ok {
					break
				}
				wait_ch, ok := v[0].(chan int)
				if !ok {
					break
				}
				v1 := []int{mgr.n_login, mgr.n_conn, cap(mgr.v_conn)}
				for _, n := range v1 {
					select {
					case wait_ch <- n:
					default:
					}
				}
			case CMD_SHUTDOWN:
				cmd1 := SysCmd{Id: CMD_FORCE_EXIT, Param: cmd.Param}
				for _, conn := range mgr.v_conn {
					select {
					case conn.chan_cmd <- cmd1:
					default:
					}
				}
				mgr.stop_accept_conn = true
			}
		case cb := <-mgr.chan_queIterateCb:
			for i := 0; i < len(mgr.v_conn); i++ {
				conn := &mgr.v_conn[i]
				if conn.IsUsed() {
					cb(conn)
				}
			}
		}
	}
}

func (mgr *ConnMgr) del_conn(conn_del conn.ConnType) {
	if idx, ok := mgr.indexConn[conn_del]; ok {
		c := &mgr.v_conn[idx]
		alive := !c.IsBroken()
		// 删除索引
		delete(mgr.indexConn, c.conn)
		if len(c.sid) > 0 {
			delete(mgr.indexSid, c.sid)
		}
		if c.userid > 0 {
			delete(mgr.indexUid, c.userid)
		}
		// 回收位置
		mgr.idle_index = append(mgr.idle_index, idx)
		// 计数器
		mgr.n_conn--
		if c.userid > 0 {
			mgr.n_login--
		}
		// 广播队列(不能在此close chanel，统一到广播服务中close)
		mgr.broadcast_svc.close_chan(c.chan_msg_trans)
		// 清空连接信息
		c.init(&init_conn_t{}, mgr, idx)
		// 关闭连接
		if alive {
			if mgr.cfg.LogQueue > 0 {
				log.Printf("Close conn %s\n", conn_del.RemoteAddr())
			}
			conn_del.Close()
		}
	}
}

func (mgr *ConnMgr) add_conn(initInfo *init_conn_t) *ConnInfo {
	if _, ok := mgr.indexConn[initInfo.conn]; ok {
		mgr.del_conn(initInfo.conn)
	}
	// 分配位置，先从回收位置尝试分配，再到新位置尝试分配
	idx := -1
	len_idle := len(mgr.idle_index)
	if len_idle > 0 {
		idx = mgr.idle_index[len_idle-1]
		mgr.idle_index = mgr.idle_index[:len_idle-1]
	} else if mgr.alloc_index < cap(mgr.v_conn) {
		idx = mgr.alloc_index
		mgr.v_conn = append(mgr.v_conn, ConnInfo{})
		mgr.alloc_index++
	}
	if idx < 0 {
		// 分配位置失败
		log.Printf("Failed to alloc conn index for %s\n", initInfo.conn.RemoteAddr())
		initInfo.conn.Close()
		return nil
	}
	// 初始化&注册连接信息
	mgr.v_conn[idx].init(initInfo, mgr, idx)
	mgr.v_conn[idx].isBroken = false
	mgr.v_conn[idx].time_broken = time.Time{}

	// 新增索引
	mgr.indexConn[initInfo.conn] = idx
	// 计数器
	mgr.n_conn++
	// 广播队列
	mgr.broadcast_svc.add_chan(mgr.v_conn[idx].chan_msg_trans)
	//
	return &mgr.v_conn[idx]
}

// 接收系统消息队列(命令)
func (mgr *ConnMgr) Chan_cmd() chan<- SysCmd {
	return mgr.chan_cmd
}

// 推送消息给指定uid处理
// smsg - 消息体，由调用者跟消息处理器约定格式，string or []byte
// ext - 额外参数，当调用者需要跟消息处理器交互时需要给出，具体内容须二者约定，默认情况下其内容为
//		ext[0] - io.Writer，用于输出信息给调用者
//		ext[1] - chan int，用于通知调用者处理完毕，消息处理器处理结束时一般执行chan <- 1
func (mgr *ConnMgr) PushMsgToUid(uid_to uint, smsg interface{}, ext ...interface{}) {
	v := make([]interface{}, 2, 2+len(ext))
	v[0] = uid_to
	v[1] = smsg
	if len(ext) > 0 {
		v = append(v, ext...)
	}
	p := SysCmd{Id: CMD_MSGTO_UID, Param: v}
	mgr.Chan_cmd() <- p
}
func (mgr *ConnMgr) PushMsgToConn(conn conn.ConnType, smsg interface{}, ext ...interface{}) {
	v := make([]interface{}, 2, 2+len(ext))
	v[0] = conn
	v[1] = smsg
	if len(ext) > 0 {
		v = append(v, ext...)
	}
	p := SysCmd{Id: CMD_MSGTO_CONN, Param: v}
	mgr.Chan_cmd() <- p
}

// 查询uid对应的 *ConnInfo
//	mseconds_timeout - 等待时间，ms，-1表示一直等待直到收到结果
//	uids - 一个或多个uid
// 返回 []*ConnInfo 与 uids 一一对应，找不到的对应为nil
func (mgr *ConnMgr) QueryConnInfoOfUid(mseconds_timeout int, uids ...uint64) []*ConnInfo {
	l := len(uids)
	if l == 0 {
		return []*ConnInfo{}
	}
	wait_ch := make(chan *ConnInfo, 1+l)
	v := make([]interface{}, 2, 1+l)
	v[0] = uids[0]
	v[1] = wait_ch
	for i := 1; i < l; i++ {
		v = append(v, uids[i])
	}
	p := SysCmd{Id: CMD_QUERY_UID, Param: v}
	if mseconds_timeout < 0 {
		mgr.Chan_cmd() <- p
	} else {
		select {
		case mgr.Chan_cmd() <- p:
		case <-time.After(time.Millisecond * time.Duration(mseconds_timeout)):
			return []*ConnInfo{}
		}
	}

	vc := make([]*ConnInfo, l)
	t_wait := mseconds_timeout
	for i := 0; i < l; i++ {
		if t_wait < 0 {
			c := <-wait_ch
			vc[i] = c
		} else {
			select {
			case c := <-wait_ch:
				vc[i] = c
			case <-time.After(time.Millisecond * time.Duration(t_wait)):
				log.Printf("Query uid %v timeout\n", uids)
			}
			if t_wait > 100 { // ms
				// 只有首次才需要等待足够时间
				t_wait = 100
			}
		}
	}
	return vc
}

// 查询队列数量，返回 登录数、连接数、队列空间
// mseconds_timeout - 等待时间，ms，-1表示一直等待直到收到结果
func (mgr *ConnMgr) QueryNum(mseconds_timeout int) (int, int, int) {
	ch := make(chan int, 3)
	p := SysCmd{Id: CMD_QUE_PLY_NUM, Param: []interface{}{ch}}

	if mseconds_timeout < 0 {
		mgr.Chan_cmd() <- p
	} else {
		select {
		case mgr.Chan_cmd() <- p:
		case <-time.After(time.Millisecond * time.Duration(mseconds_timeout)):
			return -1, 0, 0
		}
	}

	vr := make([]int, 3)
	t_wait := mseconds_timeout
	for i := 0; i < len(vr); i++ {
		if mseconds_timeout < 0 {
			vr[i] = <-ch
		} else {
			select {
			case vr[i] = <-ch:
			case <-time.After(time.Millisecond * time.Duration(t_wait)):
			}
			if t_wait > 100 { // ms
				// 只有首次才需要等待足够时间
				t_wait = 100
			}
		}
	}
	return vr[0], vr[1], vr[2]
}

// 队列遍历回调
// 	timeout - 插入队列的超时时间，毫秒ms，默认500ms
// 返回非nil error表示超时
// 注意： 回调函数f中不能执行长时间的操作，否则会影响整个队列的反应速度
func (mgr *ConnMgr) QueueIterateCall(f QueueIterateCallBack, timeout ...int) error {
	t_ms := 500
	if len(timeout) > 0 {
		t_ms = timeout[0]
	}
	select {
	case mgr.chan_queIterateCb <- f:
	case <-time.After(time.Millisecond * time.Duration(t_ms)):
		err := fmt.Errorf("timeout")
		if mgr.cfg.LogQueue > 0 {
			log.Printf("QueueIterateCall %v", err)
		}
		return err
	}
	return nil
}

// 停止接入新连接
func (mgr *ConnMgr) AcceptStop() {
	mgr.stop_accept_conn = true
}

// 继续接入新连接
func (mgr *ConnMgr) AcceptContinue() {
	mgr.stop_accept_conn = false
}

/*









 */
func (mgr *ConnMgr) GetWsHandler() func(*websocket.Conn) {
	return func(ws *websocket.Conn) {
		tws := conn.NewConnTypeWebsocket(ws, mgr.cfg.ConnTimeout)
		defer func() {
			ws.Close()
			mgr.chan_brk_conn <- tws
			if mgr.cfg.LogNet > 0 {
				log.Printf("ws post-close: %s", ws.Request().RemoteAddr)
			}
		}()
		if mgr.stop_accept_conn {
			return
		}
		chan_msg_in := make(chan []byte, mgr.cfg.PreMsgNumPerConn)
		wi := init_conn_t{tws, chan_msg_in}
		mgr.chan_add_conn <- wi

		if mgr.cfg.LogNet > 0 {
			log.Printf("ws Client connected: %s", ws.Request().RemoteAddr)
		}
	outloop:
		for {
			var message []byte
			ws.SetReadDeadline(time.Now().Add(time.Duration(4*mgr.cfg.ConnTimeout) * time.Second))
			err := websocket.Message.Receive(ws, &message)
			if err != nil {
				if neterr, ok := err.(net.Error); ok && neterr.Timeout() {
					continue
				}
				if mgr.cfg.LogNet > 0 {
					log.Printf("ws close on receive %s Error: %s\n", ws.Request().RemoteAddr, err.Error())
				}
				return
			}
			select {
			case chan_msg_in <- message:
			case <-time.After(time.Second * time.Duration(120)):
				log.Println("ws msg in time out")
				break outloop
			}
		}
	}
}

// 启动默认的websoket服务
func (mgr *ConnMgr) DefaultWebsocketServe(uri_pattern, laddr string) error {
	http.Handle(uri_pattern, websocket.Handler(mgr.GetWsHandler()))
	s := &http.Server{
		Addr:         laddr,
		Handler:      nil,
		WriteTimeout: time.Duration(mgr.cfg.ConnTimeout) * time.Second,
		//ReadTimeout:  time.Duration(2*mgr.cfg.ConnTimeout) * time.Second,
	}
	err := s.ListenAndServe()
	if err != nil {
		return err
	}
	return nil
}

// 启动默认的socket服务
// The network net must be a stream-oriented network: "tcp", "tcp4",
// "tcp6", "unix" or "unixpacket".
// See Dial for the syntax of laddr.
func (mgr *ConnMgr) DefaultNetConnServe(net_type, laddr string, fcn conn.StreamFrameCutterFactory) error {
	l, err := net.Listen(net_type, laddr)
	if err != nil {
		return err
	}

	defer l.Close()
	var tempDelay time.Duration // how long to sleep on accept failure
	for {
		rw, e := l.Accept()
		if e != nil {
			if ne, ok := e.(net.Error); ok && ne.Temporary() {
				if tempDelay == 0 {
					tempDelay = 5 * time.Millisecond
				} else {
					tempDelay *= 2
				}
				if max := 1 * time.Second; tempDelay > max {
					tempDelay = max
				}
				//srv.logf("http: Accept error: %v; retrying in %v", e, tempDelay)
				time.Sleep(tempDelay)
				continue
			}
			return e
		}
		tempDelay = 0
		//		c, err := srv.newConn(rw)
		//		if err != nil {
		//			continue
		//		}
		//		c.setState(c.rwc, StateNew) // before Serve can return
		//		go c.serve()
		go mgr.netConnHandle(rw, fcn.NewCutter())
	}

	return nil
}

func (mgr *ConnMgr) netConnHandle(c net.Conn, fc conn.StreamFrameCutter) {
	tc := conn.NewConnTypeNetConn(c, mgr.cfg.ConnTimeout)
	defer func() {
		tc.Close()
		mgr.chan_brk_conn <- tc
		if mgr.cfg.LogNet > 0 {
			log.Printf("netConn post-close: %s", tc.RemoteAddr())
		}
	}()
	if mgr.stop_accept_conn {
		return
	}
	chan_msg_in := make(chan []byte, mgr.cfg.PreMsgNumPerConn)
	ci := init_conn_t{tc, chan_msg_in}
	mgr.chan_add_conn <- ci

	if mgr.cfg.LogNet > 0 {
		log.Printf("netConn Client connected: %s", tc.RemoteAddr())
	}

	l_buf := mgr.cfg.StreamRcvBuffLen
	if l_buf == 0 {
		l_buf = 1024
	}
	buf := make([]byte, l_buf)
outloop:
	for {
		c.SetReadDeadline(time.Now().Add(time.Second * time.Duration(mgr.cfg.ConnTimeout)))
		n, err := c.Read(buf)
		if err != nil {
			if neterr, ok := err.(net.Error); ok && neterr.Timeout() {
				if n > 0 {
					fc.Feed(buf[:n])
				}
				continue
			}
			if mgr.cfg.LogNet > 0 {
				log.Printf("netConn close on receive %s Error: %s\n", tc.RemoteAddr(), err.Error())
			}
			return
		}

		err = fc.Feed(buf[:n])
		if err != nil {
			if mgr.cfg.LogNet > 0 {
				log.Printf("netConn %s Feed error: %v", tc.RemoteAddr(), err)
			}
			return
		}
		for n > 0 {
			pkg, err := fc.Cut()
			if err != nil {
				if mgr.cfg.LogNet > 0 {
					log.Printf("netConn %s CUT ERROR: %v", tc.RemoteAddr(), err)
				}
				return
			}

			// 包还不完整
			if pkg == nil {
				break
			}

			if pkg != nil && len(pkg) > 0 {
				select {
				case chan_msg_in <- pkg:
				case <-time.After(time.Second * time.Duration(120)):
					log.Println("socket msg in time out")
					break outloop
				}
			}

			// 一次性可能收到多个包
			n -= len(pkg)
		}
	}
}
