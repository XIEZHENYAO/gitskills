/*
	连接管理器 配置

	Donnie.L
	2015.06
*/

package connmgr

// 连接管理器配置
type ConnCfg struct {
	Cap_que                 int // 队列最大数量
	ConnTimeout             int // 连接收发消息超时时间秒数
	LogNet                  int // 是否显示网络连接日志
	LogQueue                int // 是否显示连接队列日志
	TimeoutBroadcast        int // 广播时插入单个用户转发队列超时时间，微妙
	DropOnUserBroadcastFull int // 广播时如果用户转发队列满是否丢弃抓发给该用户的消息
	PreSizeConnIndex        int // 索引预分配空间
	PreSizeChan             int // channel预分配空间
	PreMsgNumPerConn        int // 每个连接chan_msg_in预先分配空间
	ReLoginDeal             int // 重复登录如何处置： 0-双方都踢下线 1-用新连接替换原连接继续服务
	Broadcast_rouine        int // 广播队列数
	StreamRcvBuffLen        int // socket stream receive buff length
}

// 用于网络游戏客户端连接的默认连接管理器配置
var UserConnCfg = ConnCfg{
	Cap_que:                 2000,
	ConnTimeout:             10,
	LogNet:                  0,
	LogQueue:                1,
	TimeoutBroadcast:        100,
	DropOnUserBroadcastFull: 0,
	PreSizeConnIndex:        100,
	PreSizeChan:             20,
	PreMsgNumPerConn:        10,
	ReLoginDeal:             0,
	Broadcast_rouine:        1,
}
