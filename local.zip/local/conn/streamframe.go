/*
	数据流封包切割接口
*/

package conn

import (
	"bytes"
	"encoding/binary"
	"fmt"
)

const defaultBufSize = 4096
const defaultMaxLen = 1024 * 1024 * 2
const HdrSize = 4

//
//
// 封包切割接口
type StreamFrameCutter interface {
	Feed(bs []byte) error
	// 新读入数据bs，返回切割好的封包
	// 如果当前数据还不足以组成一个封包，返回的[]byte为nil
	Cut() ([]byte, error)
}

// 封包切割接口的工厂接口
type StreamFrameCutterFactory interface {
	NewCutter() StreamFrameCutter
}

//
//
//
//
// 原数据切割器，不做任何修饰原样返回
type RawCut struct {
	bs []byte
}

func (r *RawCut) Feed(bs []byte) error {
	r.bs = bs
	return nil
}

func (r *RawCut) Cut() ([]byte, error) {
	return r.bs, nil
}

// 原数据切割器工厂
type RawCutFactory struct{}

func (f *RawCutFactory) NewCutter() StreamFrameCutter {
	return &RawCut{}
}

//
//
//
//
// 按换行符\n切分的文本消息切割器
// 切割后的消息包不含\n
type TextLineCut struct {
	buff   []byte
	length int //剩余包长度
	fc     *TextLineCutFactory
}

func (r *TextLineCut) Feed(bs []byte) error {
	maxl := r.fc.MaxLen
	if maxl == 0 {
		maxl = defaultMaxLen // 默认最大数据包大小
	}

	if len(r.buff)+len(bs) > maxl {
		return fmt.Errorf("TOO-LARGE-PACKAGE-SIZE-THAN %d", maxl)
	}

	r.length += len(bs)

	r.buff = append(r.buff, bs...)

	return nil
}

func (r *TextLineCut) Cut() ([]byte, error) {
	pos_ln := bytes.IndexByte(r.buff[0:], '\n')
	if pos_ln < 0 {
		//fmt.Printf("pkg part %d of %d\n", len(bs), len(r.buff))
		return nil, nil
	} else {
		pkg_len := pos_ln + 1
		//fmt.Printf("pkg len %d, pos %d, last2:%d,%d\n", r.l_pkg, pos_ln, r.buff[r.l_pkg-2], r.buff[r.l_pkg-1])

		pkg := make([]byte, pkg_len-1)
		copy(pkg, r.buff[:pkg_len-1])

		r.length -= pkg_len

		if r.length > 0 { // 还有剩余 置顶
			copy(r.buff[0:], r.buff[pkg_len:])
		}

		return pkg, nil // 返回的包不含\n
	}
}

// 按换行符\n切分的文本消息切割器工厂
type TextLineCutFactory struct {
	LenBuff int // 缓存大小
	MaxLen  int // 最大包字节数
}

func (f *TextLineCutFactory) NewCutter() StreamFrameCutter {
	l := f.LenBuff
	if l == 0 {
		l = defaultBufSize
	}
	return &TextLineCut{
		buff: make([]byte, 0, l),
		fc:   f,
	}
}

//
//  前 4字节 长度
//  切割LengthValue类型包
type LengthValueCut struct {
	buff        []byte
	length      int // 剩余包长度
	max_pkt_len int // 最大包长度
}

func (r *LengthValueCut) Feed(bs []byte) error {

	// 扩大缓存
	if r.length+len(bs) > len(r.buff) {
		newBuf := make([]byte, ((r.length+len(bs))/defaultBufSize+1)*defaultBufSize)
		copy(newBuf, r.buff)
		r.buff = newBuf
	}

	// 添加到末尾
	copy(r.buff[r.length:], bs)
	r.length += len(bs)
	return nil
}

func (r *LengthValueCut) Cut() ([]byte, error) {
	// 如果有包 将剩余的包移到开头

	// 保证消息头大小
	if r.length < HdrSize {
		return nil, nil
	}
	msg_len := int(binary.BigEndian.Uint32(r.buff[0:HdrSize]))
	if msg_len > r.max_pkt_len {
		return nil, fmt.Errorf("TOO-LARGE-PACKET-SIZE-THAN %d, MSG_LEN %d r.length %d, content %s",
			r.max_pkt_len, msg_len, r.length, string(r.buff[HdrSize:r.length]))
	}

	// 包不完整
	if r.length-HdrSize < msg_len {
		return nil, nil
	} else {
		pkt_len := HdrSize + msg_len

		pkt := make([]byte, pkt_len)
		copy(pkt, r.buff[0:pkt_len])

		r.length -= pkt_len

		if r.length > 0 { //将剩下包置顶
			copy(r.buff[0:], r.buff[pkt_len:])
		}

		// 返回整个包，包含头部
		return pkt, nil
	}
}

// LV模式切割工厂
type LengthValueCutFactory struct {
	Max_pkt_len int
}

func (f *LengthValueCutFactory) NewCutter() StreamFrameCutter {
	max_pkt_len := f.Max_pkt_len
	if max_pkt_len == 0 {
		max_pkt_len = defaultMaxLen
	}

	return &LengthValueCut{
		buff:        make([]byte, 0, defaultBufSize),
		max_pkt_len: max_pkt_len,
	}
}
