package conn

import (
	"fmt"
	"net/url"
	"regexp"
	"strconv"
)

// 服务器地址描述，可分解自url形式的配置字符串
type ServerAddrInfo struct {
	Scheme   string // 连接类型： tcp/udp/.../ws/wss，除ws外的见net.Dial说明
	Host     string // 服务器地址[:port]
	HostOnly string // 服务器地址不含port
	Port     int    // 服务器port
	Uri      string // websocket时需要的uri，如 /serv
}

// 从url形式的配置字符串中获取服务器配置信息
// websocket格式： ws[s]://server[:port]/uri
// socket格式：  tcp://server:port
//		其中协议见net.Dial要求
func (c *ServerAddrInfo) ParseAddrFromString(s_url string) error {
	//"list://63.65.21:998/394"
	//parse result: &url.URL{Scheme:"list", Opaque:"", User:(*url.Userinfo)(nil), Host:"63.65.21:998", Path:"/394", RawPath:"", RawQuery:"", Fragment:""}
	url_, err := url.ParseRequestURI(s_url)
	if err != nil {
		return err
	}
	//	log.Printf("url parse:\n%s\n%#v", s_url, url_)

	c.Scheme = url_.Scheme
	c.Uri = url_.Path
	c.Host = url_.Host
	v := regexHostPort.FindAllStringSubmatch(url_.Host, -1)
	if len(v) != 1 || len(v[0][1]) == 0 {
		err := fmt.Errorf("error host[:port] format - %s", url_.Host)
		return err
	}
	c.HostOnly = v[0][1]
	port, _ := strconv.ParseInt(v[0][3], 10, 0)
	if port == 0 {
		switch url_.Scheme {
		case "ws":
			port = 80
		case "wss":
			port = 443
		}
	}
	c.Port = int(port)

	return nil
}

// [[all-string, host, :port, port]]
var regexHostPort = regexp.MustCompile(`^\s*(.*?)\s*(:\s*([\d\w]*))?\s*$`) //(`^(.*?)(:(\d*))?$`)
