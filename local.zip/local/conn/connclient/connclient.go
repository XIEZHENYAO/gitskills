/*
	连接客户端
	lindl 2016.07
*/

package connclient

import (
	"fmt"
	"log"
	"net"
	"strconv"
	"sync/atomic"
	"time"

	"local/conn"

	"code.google.com/p/go.net/websocket"
)

/*





	连接客户端
		简化客户端连接的创建和响应
		使用管道或者异步接口响应连接和消息
	例子见 TestClient*()
*/
type ConnClient struct {
	unique_id   uint64                 // 各ConnClient中的唯一ID
	cfg         ConnCfg                // 配置
	handler     ConnAsyncHandler       // 异步处理接口，此接口和管道仅一种有效
	chan_msg_in chan []byte            // 消息in
	chan_broken chan int               // 断线通知
	conn        conn.ConnType          // 连接
	is_ok       bool                   // 连接是否正常
	frameCutter conn.StreamFrameCutter // 流协议封包切割接口
}

var uniqueIdAlloctorConnClient uint64

// 新建一个用于连接的结构，urlServerAddr见 ServerAddrInfo.ParseAddrFromString 定义
func NewConnClient(urlServerAddr string) *ConnClient {
	cc := &ConnClient{}
	cc.cfg.ServerAddr.ParseAddrFromString(urlServerAddr)
	cc.unique_id = atomic.AddUint64(&uniqueIdAlloctorConnClient, 1)
	cc.cfg.PreMsgNumPerConn = 10
	return cc
}

// 根据cfg配置发起连接
func (cl *ConnClient) Connect() error {
	if cl.cfg.ServerAddr.Scheme == "ws" || cl.cfg.ServerAddr.Scheme == "wss" {
		return cl.wsConnect()
	} else {
		return cl.netConnConnect()
	}
}

// 获取连接唯一ID (在所有ConnClient中唯一)
func (cl *ConnClient) GetUniqueId() uint64 {
	return cl.unique_id
}

// 描述字符串
func (cl *ConnClient) Desc() string {
	return fmt.Sprintf("<%d#%s>", cl.unique_id, cl.GetConn().RemoteAddr())
}

// 获取连接，return nil if connect fail or not connect yet
func (cl *ConnClient) GetConn() conn.ConnType {
	return cl.conn
}
func (cl *ConnClient) IsBroken() bool {
	return !cl.is_ok
}

// 用于接收消息的管道
func (cl *ConnClient) Chan_msg_in() <-chan []byte {
	return cl.chan_msg_in
}

// 用于监听断线的管道
func (cl *ConnClient) Chan_broken() <-chan int {
	return cl.chan_broken
}

// 读写配置
func (cl *ConnClient) Cfg() *ConnCfg {
	return &cl.cfg
}

// 流协议需要设置封包切割接口，否则将使用默认RawCut。 ws协议不需要切包
func (cl *ConnClient) SetStreamFrameCutter(fc conn.StreamFrameCutter) {
	cl.frameCutter = fc
}

// 设置异步处理接口，设置有效接口后，channel将不再起作用
func (cl *ConnClient) SetAsyncHandler(handler ConnAsyncHandler) {
	cl.handler = handler
}

func (cl *ConnClient) wsConnect() error {
	//s_srv := "wss://echo.websocket.org:443/"
	// websocket.Dial 需要明确给出port
	addr := &cl.cfg.ServerAddr
	s_srv := addr.Scheme + "://" + addr.HostOnly + ":" + strconv.Itoa(addr.Port) + addr.Uri
	ws, err := websocket.Dial(s_srv, "", s_srv)
	if err != nil {
		if cl.cfg.LogNet > 0 {
			log.Printf("ws-client connect to %s FAILED: %v", s_srv, err)
		}
		if cl.handler != nil {
			cl.handler.OnConnError(err)
			cl.handler.OnConnClosed()
		}
		return err
	}
	cl.chan_msg_in = make(chan []byte, cl.cfg.PreMsgNumPerConn)
	cl.chan_broken = make(chan int, 1)
	cl.conn = conn.NewConnTypeWebsocket(ws, cl.cfg.ConnTimeout)
	cl.is_ok = true

	if cl.cfg.LogNet > 0 {
		log.Printf("ws-client connect to %s success", cl.Desc())
	}
	if cl.handler != nil {
		cl.handler.OnConnOpen(cl.conn)
	}
	go func() {
		defer func() {
			cl.conn.Close()
			if cl.cfg.LogNet > 0 {
				log.Printf("ws-client post-close: %s", cl.Desc())
			}
			cl.chan_broken <- 1
			if cl.handler != nil {
				cl.handler.OnConnClosed()
			}
		}()
		for {
			var message []byte
			err := websocket.Message.Receive(ws, &message)
			if err != nil {
				cl.is_ok = false
				if cl.cfg.LogNet > 0 {
					log.Printf("ws-client close on receive %s Error: %s\n", cl.Desc(), err.Error())
				}
				if cl.handler != nil {
					cl.handler.OnConnError(err)
				}
				return
			}
			if cl.handler == nil {
				cl.chan_msg_in <- message
			} else {
				cl.handler.OnConnMessage(message)
			}
		}
	}()
	return nil
}

func (cl *ConnClient) netConnConnect() error {
	cc, err := net.Dial(cl.cfg.ServerAddr.Scheme, cl.cfg.ServerAddr.Host)
	if err != nil {
		if cl.cfg.LogNet > 0 {
			log.Printf("net-client connect to %s FAILED: %v", cl.cfg.ServerAddr.Host, err)
		}
		if cl.handler != nil {
			cl.handler.OnConnError(err)
			cl.handler.OnConnClosed()
		}
		return err
	}
	cl.chan_msg_in = make(chan []byte, cl.cfg.PreMsgNumPerConn)
	cl.chan_broken = make(chan int, 1)
	cl.conn = conn.NewConnTypeNetConn(cc, cl.cfg.ConnTimeout)
	cl.is_ok = true
	if cl.frameCutter == nil {
		factory := &conn.RawCutFactory{}
		cl.frameCutter = factory.NewCutter()
	}

	if cl.cfg.LogNet > 0 {
		log.Printf("net-client connect to %s success", cl.Desc())
	}
	if cl.handler != nil {
		cl.handler.OnConnOpen(cl.conn)
	}

	go func() {
		defer func() {
			cl.conn.Close()
			if cl.cfg.LogNet > 0 {
				log.Printf("net-client post-close: %s", cl.Desc())
			}
			cl.chan_broken <- 1
			if cl.handler != nil {
				cl.handler.OnConnClosed()
			}
		}()
		//
		l_buf := cl.cfg.StreamRcvBuffLen
		if l_buf == 0 {
			l_buf = 1024
		}
		buf := make([]byte, l_buf)
		for {
			n, err := cc.Read(buf)
			if err != nil {
				cl.is_ok = false
				if cl.cfg.LogNet > 0 {
					log.Printf("net-client close on receive %s Error: %s\n", cl.Desc(), err.Error())
				}
				if cl.handler != nil {
					cl.handler.OnConnError(err)
				}
				return
			}

			err = cl.frameCutter.Feed(buf[:n])
			if err != nil {
				cl.is_ok = false
				if cl.cfg.LogNet > 0 {
					log.Printf("net-client %s Feed error: %v", cl.Desc(), err)
				}
				if cl.handler != nil {
					cl.handler.OnConnError(err)
				}
				return
			}
			for n > 0 {
				pkg, err := cl.frameCutter.Cut()
				if err != nil {
					cl.is_ok = false
					if cl.cfg.LogNet > 0 {
						log.Printf("net-client %s CUT ERROR: %v", cl.Desc(), err)
					}
					if cl.handler != nil {
						cl.handler.OnConnError(err)
					}
					return
				}

				// 包还不完整
				if pkg == nil {
					break
				}

				if pkg != nil && len(pkg) > 0 {
					if cl.handler == nil {
						cl.chan_msg_in <- pkg
					} else {
						cl.handler.OnConnMessage(pkg)
					}
				}

				// 一次性可能收到多个包
				n -= len(pkg)
			}
		}
	}()

	return nil
}

// 连接配置
type ConnCfg struct {
	ServerAddr       conn.ServerAddrInfo // 服务器地址
	LogNet           int                 // 是否显示网络连接日志
	ConnTimeout      int                 // 连接发消息超时时间秒数，默认0不超时
	StreamRcvBuffLen int                 // socket stream receive buff length,default 1024
	PreMsgNumPerConn int                 // 每个连接chan_msg_in预先分配空间
}

/*




	异步处理接口，用于替代channel
*/
type ConnAsyncHandler interface {
	OnConnOpen(conn conn.ConnType) // 如果连接失败将不会有open却有error和closed
	OnConnError(err error)
	OnConnClosed()
	OnConnMessage(msg_bs []byte)
}

/*









	测试


*/
// 同步
func TestClient() {
	//c := NewConnClient("ws://echo.websocket.org:80")
	c := NewConnClient("tcp://localhost:12345")
	c.Cfg().LogNet = 1
	if err := c.Connect(); err != nil {
		log.Printf("connect failed: %v", err)
		return
	}
	c.GetConn().Send("hello,first")

	n := 0
outloop:
	for {
		select {
		case <-time.After(time.Millisecond * time.Duration(2000)):
			c.GetConn().Send("hello")
		//log.Println("send")
		case <-c.Chan_broken():
			log.Printf("%s broken", c.Desc())
			break outloop
		case msg := <-c.Chan_msg_in():
			log.Println(string(msg))
			n++
			if n >= 3 {
				c.GetConn().Close()
			}
		}
	}
}

// 异步
func TestClient1() {
	handler := sampleClientHandler{}
	//c := NewConnClient("ws://echo.websocket.org:80")
	c := NewConnClient("tcp://localhost:12345")
	c.Cfg().LogNet = 1
	c.SetAsyncHandler(&handler)
	if c.Connect() == nil {
		n := 0
		for handler.cnt < 3 && n < 5 {
			time.Sleep(time.Second * 2)
			c.GetConn().Send(fmt.Sprintf("hello, %d", handler.cnt))
			n++
		}
		c.GetConn().Close()
	}
}

type sampleClientHandler struct{ cnt int }

func (h *sampleClientHandler) OnConnOpen(conn conn.ConnType) {
	log.Printf("handler: OnConnOpen %s", conn.RemoteAddr())
	conn.Send("hello,first")
}
func (h *sampleClientHandler) OnConnError(err error) {
	log.Printf("handler: OnConnError %s", err)
}
func (h *sampleClientHandler) OnConnClosed() {
	log.Printf("handler: OnConnClosed")
}
func (h *sampleClientHandler) OnConnMessage(msg_bs []byte) {
	log.Printf("handler: OnConnMessage %s", string(msg_bs))
	h.cnt++
}
