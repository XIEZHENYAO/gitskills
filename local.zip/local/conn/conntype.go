/*
	连接类型： websocket or socket

	Donnie.L
	2015.10
*/

package conn

import (
	"errors"
	"net"
	"time"

	"code.google.com/p/go.net/websocket"
)

//
// 连接类型接口
//
type ConnType interface {
	// 发送消息，v: string or []byte，二进制用[]byte
	Send(v interface{}) error
	// 关闭连接
	Close() error
	// 连接对方的地址描述字符串
	RemoteAddr() string
}

//
// 连接类型: websocket
type ConnTypeWebsocket struct {
	ws      *websocket.Conn
	timeout int
}

func NewConnTypeWebsocket(ws *websocket.Conn, timeout int) *ConnTypeWebsocket {
	return &ConnTypeWebsocket{ws, timeout}
}

func (tws *ConnTypeWebsocket) Send(v interface{}) error {
	if tws.timeout > 0 {
		tws.ws.SetWriteDeadline(time.Now().Add(time.Duration(tws.timeout) * time.Second))
	}
	return websocket.Message.Send(tws.ws, v)
}

func (tws *ConnTypeWebsocket) Close() error {
	return tws.ws.Close()
}

func (tws *ConnTypeWebsocket) RemoteAddr() string {
	if tws.ws.IsServerConn() {
		return tws.ws.Request().RemoteAddr
	} else {
		return tws.ws.RemoteAddr().String()
	}
}

//
// 连接类型： net.Conn
type ConnTypeNetConn struct {
	c       net.Conn
	timeout int
}

func NewConnTypeNetConn(c net.Conn, timeout int) *ConnTypeNetConn {
	return &ConnTypeNetConn{c, timeout}
}

func (tc *ConnTypeNetConn) Send(v interface{}) error {
	if tc.timeout > 0 {
		tc.c.SetWriteDeadline(time.Now().Add(time.Duration(tc.timeout) * time.Second))
	}
	if bs, ok := v.([]byte); ok {
		_, err := tc.c.Write(bs)
		return err
	}
	if s, ok := v.(string); ok {
		_, err := tc.c.Write([]byte(s))
		return err
	}
	return errors.New("unknown v to Send")
}

func (tc *ConnTypeNetConn) Close() error {
	return tc.c.Close()
}

func (tc *ConnTypeNetConn) RemoteAddr() string {
	return tc.c.RemoteAddr().String()
}
