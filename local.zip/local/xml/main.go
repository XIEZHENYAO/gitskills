// xml project main.go
package xml

import (
	"container/list"
	"encoding/xml"
	"fmt"
	"io"
	"os"
	"strings"
)

const (
	Int        = 1
	Float      = 2
	String     = 3
	CommentStr = "<!Comment>"
	RootStr    = "Root"
)

var default_str string = ""
var default_int int = 0
var default_float float64 = 0
var Comment = ""

type Node struct {
	Name       string
	Value      string
	Attr       map[string]string
	attr_order []string // attr原始顺序，只保证顺序，不保证Attr中有此属性
	ChildEle   *list.List
	NodeAdd    *list.Element //Node所在的链表的元素
	NodeFather *Node
}

type DyXmlErr struct {
	msg string
}

func (e DyXmlErr) Error() string {
	return e.msg
}

func Open(file string) *Node {
	var Root *Node = &Node{Name: RootStr, Value: "", ChildEle: list.New()}
	var t xml.Token
	var err error
	xmlfile, err := os.Open(file)
	defer xmlfile.Close()
	if err != nil {
		panic(err)
	}
	decoder := xml.NewDecoder(xmlfile)
	for t, err = decoder.Token(); t != nil; t, err = decoder.Token() {
		switch t.(type) {
		case xml.Comment:
			Root.ChildEle.PushBack(&Node{Name: CommentStr, Value: string(t.(xml.Comment))})
		case xml.ProcInst:
		case xml.CharData:
			Root.Value += strings.TrimSpace(string(t.(xml.CharData).Copy()))
		case xml.StartElement:
			ele := Node{Name: "un"}
			add := Root.ChildEle.PushBack(&ele)
			parse(t, &ele, decoder, add, Root)
		case xml.EndElement:
			break
		}
		if err != nil {
			break
		}
	}
	return Root
}

//parse the xml start in xml.startElement
func parse(t xml.Token, f *Node, decoder *xml.Decoder, add *list.Element, father *Node) {
	f.Value = ""
	f.ChildEle = list.New()
	f.NodeAdd = add
	f.NodeFather = father
	s := t.(xml.StartElement)
	f.Name = s.Name.Local
	if len(s.Attr) > 0 {
		f.Attr = make(map[string]string)
		f.attr_order = make([]string, 0, len(s.Attr))
		for _, attr := range s.Attr {
			f.Attr[attr.Name.Local] = attr.Value
			f.attr_order = append(f.attr_order, attr.Name.Local)
		}
	}
	var err error
	for {
		t, err = decoder.Token()
		if err != nil {
			fmt.Println(err)
			return
		}
		switch t.(type) {
		case xml.Comment:
			f.ChildEle.PushBack(&Node{Name: CommentStr, Value: string(t.(xml.Comment)), NodeFather: f})
		case xml.ProcInst:
		case xml.CharData:
			f.Value += strings.TrimSpace(string(t.(xml.CharData).Copy()))
		case xml.StartElement:
			ele := Node{Name: "un"}
			add := f.ChildEle.PushBack(&ele)
			parse(t, &ele, decoder, add, f)
		case xml.EndElement:
			return
		}
	}
}

func (node *Node) Output(file string) {
	out, err := os.Create(file)
	defer out.Close()
	if err != nil {
		fmt.Println(err)
		return
	}
	node.Write(out)
}

func (node *Node) Write(iow io.Writer) {
	h := xml.Header
	if h[len(h)-1:] == "\n" {
		h = h[:len(h)-1]
	}
	fmt.Fprint(iow, h)
	printEle(node, iow, 0)
}

func printEle(node *Node, wr io.Writer, level int) {
	req := strings.Repeat("\t", (level))
	//<name attr=v>
	switch node.Name {
	case CommentStr:
		fmt.Fprint(wr, "\n", req, "<!--", node.Value, "-->")
	case RootStr:
		l := node.ChildEle
		if l != nil {
			for e := l.Front(); e != nil; e = e.Next() {
				temp := e.Value.(*Node)
				if temp.Name != CommentStr {
					fmt.Fprint(wr, "\n")
				}
				printEle(temp, wr, level)
			}
			if l.Len() > 0 {
				fmt.Fprint(wr, "\n", req)
			}
		}
	default:
		fmt.Fprintf(wr, "%s<%s", req, node.Name)
		for _, k := range node.attr_order {
			if v, ok := node.Attr[k]; ok {
				fmt.Fprintf(wr, " %s=\"%s\"", k, v)
			}
		}
		if (node.ChildEle != nil && node.ChildEle.Len() > 0) || len(node.Value) > 0 {
			fmt.Fprint(wr, ">")
			//value or childele
			fmt.Fprint(wr, strings.TrimSpace(node.Value))
			l := node.ChildEle
			if l != nil {
				for e := l.Front(); e != nil; e = e.Next() {
					temp := e.Value.(*Node)
					if temp.Name != CommentStr {
						fmt.Fprint(wr, "\n")
					}
					printEle(temp, wr, level+1)
				}
				if l.Len() > 0 {
					fmt.Fprint(wr, "\n", req)
				}
			}
			fmt.Fprint(wr, "</", node.Name, ">")
		} else {
			fmt.Fprint(wr, "/>")
		}
		if node.FahterNode() != nil && node.FahterNode().FahterNode() != nil && node.FahterNode().FahterNode().FahterNode() == nil {
			// 可见层第二层间空格隔开...美观？
			fmt.Fprintln(wr)
		}
	}
}

func (node *Node) GetElements(path string) ([]*Node, error) {
	paths := strings.Split(path, "/")
	return loopGet(node, paths[:]), nil
}

func loopGet(node *Node, paths []string) []*Node {
	ret := make([]*Node, 0, 10)
	l := node.ChildEle
	for e := l.Front(); e != nil; e = e.Next() {
		if len(paths) == 1 {
			switch e.Value.(type) {
			case *Node:
				temp := e.Value.(*Node)
				if temp.Name == paths[0] {
					ret = append(ret, temp)
				}
			}
		} else {
			switch e.Value.(type) {
			case *Node:
				temp := e.Value.(*Node)
				if temp.Name == paths[0] {
					ret2 := loopGet(temp, paths[1:])
					ret = append(ret, ret2...)
				}
			}
		}
	}
	return ret
}

func (node *Node) GetValue() string {
	return node.Value
}

func (node *Node) GetAttrs() map[string]string {
	return node.Attr
}

func (node *Node) Delete() interface{} {
	list := node.NodeFather.ChildEle
	return list.Remove(node.NodeAdd)
}

func (node *Node) GetPreNode() *Node {
	ele := node.NodeAdd.Prev()
	if ele != nil {
		return ele.Value.(*Node)
	}
	return nil
}

func (node *Node) GetNextNode() *Node {
	ele := node.NodeAdd.Next()
	if ele != nil {
		return ele.Value.(*Node)
	}
	return nil
}

func (node *Node) CreateNodeBefor(nodename string, nodevalue string, args ...string) (*Node, error) {
	if len(args)%2 != 0 {
		return &Node{}, DyXmlErr{msg: "args not pairs"}
	}
	ele := node.NodeAdd
	list := node.NodeFather.ChildEle
	newnode := &Node{Name: nodename, Value: nodevalue, NodeFather: node.NodeFather, Attr: make(map[string]string), attr_order: make([]string, 0, len(args)/2)}
	for i := 0; i < len(args); i += 2 {
		newnode.Attr[args[i]] = args[i+1]
		newnode.attr_order = append(newnode.attr_order, args[i])
	}
	newele := list.InsertBefore(newnode, ele)
	newnode.NodeAdd = newele
	return newnode, nil
}

func (node *Node) CreateNodeAfter(nodename string, nodevalue string, args ...string) (*Node, error) {
	if len(args)%2 != 0 {
		return &Node{}, DyXmlErr{msg: "args not pairs"}
	}
	ele := node.NodeAdd
	flist := node.NodeFather.ChildEle
	newnode := &Node{Name: nodename, Value: nodevalue, NodeFather: node.NodeFather, Attr: make(map[string]string), attr_order: make([]string, 0, len(args)/2)}
	for i := 0; i < len(args); i += 2 {
		newnode.Attr[args[i]] = args[i+1]
		newnode.attr_order = append(newnode.attr_order, args[i])
	}
	newele := flist.InsertAfter(newnode, ele)
	newnode.NodeAdd = newele
	return newnode, nil
}

func (node *Node) CreateNewChild(nodename string, nodevalue string, args ...string) (*Node, error) {
	if len(args)%2 != 0 {
		return &Node{}, DyXmlErr{msg: "args not pairs"}
	}
	flist := node.ChildEle
	newnode := &Node{Name: nodename, Value: nodevalue, Attr: make(map[string]string), attr_order: make([]string, 0, len(args)/2), NodeFather: node}
	newele := flist.PushBack(newnode)
	newnode.NodeAdd = newele
	for i := 0; i < len(args); i += 2 {
		newnode.Attr[args[i]] = args[i+1]
		newnode.attr_order = append(newnode.attr_order, args[i])
	}
	return newnode, nil
}

func (node *Node) InsertNodesAfter(inode *Node) {
	ele := node.NodeAdd
	flist := node.NodeFather.ChildEle
	nele := flist.InsertAfter(inode, ele)
	inode.NodeAdd = nele
	inode.NodeFather = node.NodeFather
}

func (node *Node) InsertNodesBefore(inode *Node) {
	ele := node.NodeAdd
	flist := node.NodeFather.ChildEle
	nele := flist.InsertBefore(inode, ele)
	inode.NodeAdd = nele
	inode.NodeFather = node.NodeFather
}

func (node *Node) InsertNodeChild(inode *Node) {
	flist := node.ChildEle
	nele := flist.PushBack(inode)
	inode.NodeAdd = nele
	inode.NodeFather = node
}

func (node *Node) CreateNewCommentBefore(str string) {
	node.CreateNodeBefor(CommentStr, str)
}

func (node *Node) CreateNewCommentAfter(str string) {
	node.CreateNodeAfter(CommentStr, str)
}

func (node *Node) DeleteCommentBefor() {
	ele := node.NodeAdd
	c := ele.Prev()
	flist := node.NodeFather.ChildEle
	if c != nil && c.Value.(*Node).Name == CommentStr {
		flist.Remove(c)
	}
}

func (node *Node) DeleteCommentAfter() {
	ele := node.NodeAdd
	c := ele.Next()
	flist := node.NodeFather.ChildEle
	if c != nil && c.Value.(*Node).Name == CommentStr {
		flist.Remove(c)
	}
}

func (node *Node) PreNode() *Node {
	ele := node.NodeAdd
	c := ele.Prev()
	if c != nil {
		return c.Value.(*Node)
	}
	return nil
}

func (node *Node) NextNode() *Node {
	ele := node.NodeAdd
	c := ele.Next()
	if c != nil {
		return c.Value.(*Node)
	}
	return nil
}

func (node *Node) FahterNode() *Node {
	return node.NodeFather
}

func (node *Node) SetValAttr(val string, args ...string) error {
	if len(args)%2 != 0 {
		return DyXmlErr{msg: "args not pairs"}
	}
	node.Value = val
	if len(node.Attr) == 0 {
		node.Attr = make(map[string]string)
		node.attr_order = make([]string, 0, len(args)/2)
	}
	for i := 0; i < len(args); i += 2 {
		if _, ok := node.Attr[args[i]]; !ok {
			node.attr_order = append(node.attr_order, args[i])
		}
		node.Attr[args[i]] = args[i+1]
	}
	return nil
}

func (node *Node) Travel(lv int, withComment bool, cb func(node *Node, lv int)) {
	if !withComment && node.Name == CommentStr {
		return
	}
	cb(node, lv)
	if node.ChildEle == nil {
		return
	}
	for e := node.ChildEle.Front(); e != nil; e = e.Next() {
		switch e.Value.(type) {
		case *Node:
			c := e.Value.(*Node)
			c.Travel(lv+1, withComment, cb)
		}
	}
}
