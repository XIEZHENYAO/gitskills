package ldes

import (
	"crypto/des"
	"fmt"
)

func Des_ecb_encrypt_pkcs5(originData, key []byte) ([]byte, error) {
	if len(originData) == 0 {
		return []byte{}, nil
	}
	block, err := des.NewCipher(key)
	if err != nil {
		return nil, err
	}
	originData = PKCS5Padding(originData, block.BlockSize())
	blockMode := NewECBEncrypter(block)
	crypted := make([]byte, len(originData))
	blockMode.CryptBlocks(crypted, originData)
	return crypted, nil
}

func Des_ecb_decrypt_pkcs5(crypted, key []byte) ([]byte, error) {
	if len(crypted) == 0 {
		return []byte{}, nil
	}
	block, err := des.NewCipher(key)
	if err != nil {
		return nil, err
	}
	if len(crypted)%block.BlockSize() != 0 {
		return nil, fmt.Errorf("error size")
	}
	blockMode := NewECBDecrypter(block)
	originData := make([]byte, len(crypted))
	blockMode.CryptBlocks(originData, crypted)
	originData = PKCS5UnPadding(originData)
	return originData, nil
}

func Des_ecb_encrypt_zf(originData, key []byte) ([]byte, error) {
	if len(originData) == 0 {
		return []byte{}, nil
	}
	block, err := des.NewCipher(key)
	if err != nil {
		return nil, err
	}
	originData = ZeroPadding(originData, block.BlockSize())
	blockMode := NewECBEncrypter(block)
	crypted := make([]byte, len(originData))
	blockMode.CryptBlocks(crypted, originData)
	return crypted, nil
}

func Des_ecb_decrypt_zf(crypted, key []byte) ([]byte, error) {
	if len(crypted) == 0 {
		return []byte{}, nil
	}
	block, err := des.NewCipher(key)
	if err != nil {
		return nil, err
	}
	if len(crypted)%block.BlockSize() != 0 {
		return nil, fmt.Errorf("error size")
	}
	blockMode := NewECBDecrypter(block)
	originData := make([]byte, len(crypted))
	blockMode.CryptBlocks(originData, crypted)
	originData = ZeroUnPadding(originData)
	return originData, nil
}
